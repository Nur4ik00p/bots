import User from "../models/user.js";
import NftProduct from "../models/nftProduct.js";

export default async function transferNft(req, res) {
  try {
    const { nftId, buyerUsername } = req.body;
    console.log("=== transferNft START ===", { nftId, buyerUsername, senderId: req.userId });

    if (!nftId || !buyerUsername) {
      return res.status(400).json({ success: false, error: "nftId и buyerUsername обязательны" });
    }

    
    const nft = await NftProduct.findById(nftId);
    if (!nft) {
      return res.status(404).json({ success: false, error: "NFT не найден" });
    }

    
    const norm = (u) => (u ? (u.startsWith("@") ? u : "@" + u) : "");

    const sellerName = norm(nft.owner);            
    const targetBuyerUsername = norm(buyerUsername); 

    
    const seller = await User.findOne({ username: sellerName });
    const buyer = await User.findOne({ username: targetBuyerUsername });

    if (!seller) {
      return res.status(404).json({ success: false, error: "Владелец (seller) не найден" });
    }
    if (!buyer) {
      return res.status(404).json({ success: false, error: "Покупатель не найден" });
    }

    
    if (!req.userId || req.userId.toString() !== seller._id.toString()) {
      return res.status(403).json({
        success: false,
        error: `Вы не владелец этого NFT (владелец: ${seller.username}, вы: ${req.userId})`,
      });
    }

    
    nft.owner = buyer.username;
    await nft.save();

    
    if (!Array.isArray(seller.purchases)) seller.purchases = [];
    if (!Array.isArray(buyer.purchases)) buyer.purchases = [];

    seller.purchases = seller.purchases.filter(
      (id) => id.toString() !== nft._id.toString()
    );
    if (!buyer.purchases.some((id) => id.toString() === nft._id.toString())) {
      buyer.purchases.push(nft._id);
    }

    
    if (Array.isArray(seller.pinnedNfts)) {
      seller.pinnedNfts = seller.pinnedNfts.filter(
        (id) => id.toString() !== nft._id.toString()
      );
    }

    await seller.save();
    await buyer.save();

    console.log("=== transferNft SUCCESS ===", {
      nftId: nft._id,
      newOwner: buyer.username,
    });

    return res.json({
      success: true,
      message: `NFT передан пользователю ${buyer.username}`,
      nft,
    });

  } catch (err) {
    console.error("=== transferNft ERROR ===", err);
    return res.status(500).json({ success: false, error: err.message });
  }
}
