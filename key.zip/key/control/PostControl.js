import PostModel from '../models/post.js';
import UserModel from '../models/user.js';
import mongoose from 'mongoose';
import webpush from 'web-push';

const ensureReactionStructure = async (postId) => {
    const post = await PostModel.findById(postId);
    if (!post) return null;

    let needsUpdate = false;
    const update = {};

    
    if (Array.isArray(post.likes)) {
        update.likes = {
            count: post.likes.length,
            users: post.likes
        };
        needsUpdate = true;
    } else if (!post.likes || typeof post.likes !== 'object') {
        update.likes = { count: 0, users: [] };
        needsUpdate = true;
    }

    
    if (Array.isArray(post.dislikes)) {
        update.dislikes = {
            count: post.dislikes.length,
            users: post.dislikes
        };
        needsUpdate = true;
    } else if (!post.dislikes || typeof post.dislikes !== 'object') {
        update.dislikes = { count: 0, users: [] };
        needsUpdate = true;
    }

    if (needsUpdate) {
        return await PostModel.findByIdAndUpdate(
            postId,
            { $set: update },
            { new: true }
        );
    }

    return post;
};


const generateTransactionId = () => {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};


const addPostReward = async (userId) => {
    try {
        const rewardAmount = 13;
        // Генерируем ID, который точно будет уникальным
        const tId = Date.now() + Math.floor(Math.random() * 1000);

        await UserModel.collection.updateOne(
            { _id: new mongoose.Types.ObjectId(userId) },
            {
                $inc: { balance: rewardAmount },
                $push: {
                    transactions: {
                        transactionId: String(tId), // Принудительно в строку
                        type: 'topup',              // Самый нейтральный тип
                        amount: rewardAmount,
                        description: 'Начисление за пост',
                        date: new Date(),
                        createdAt: new Date()      // Твой контроллер ищет это поле!
                    }
                }
            }
        );
    } catch (err) {
        console.error('Ошибка записи награды:', err);
    }
};
export const create = async (req, res) => {
    try {
        // 1. Создаем объект поста. 
        // Добавляем title и channelId, так как Mongoose их требует
        const doc = new PostModel({
            text: req.body.text,
            imageUrl: req.body.imageUrl,
            videoUrl: req.body.videoUrl,
            tags: req.body.tags,
            user: req.userId,
            // ИСПРАВЛЕНИЕ: передаем обязательные поля
            title: req.body.title || 'Новый пост', // Если фронт не шлет title
            channelId: req.body.channelId || new mongoose.Types.ObjectId(), // Временная заглушка или ID канала
        });

        const post = await doc.save();

        // --- ЛОГИКА ПУШ-УВЕДОМЛЕНИЙ ---
        const author = await UserModel.findById(req.userId);
        const authorName = author ? (author.fullName || author.username || 'Пользователь') : 'Участник';

        const subscribers = await UserModel.find({ 
            pushSubscription: { $exists: true, $ne: null },
            _id: { $ne: req.userId } 
        });
// PostControl.js
const payload = JSON.stringify({
  title: 'AtomGlide',
  // Проверяем: если текста нет, пишем "Посмотрете новый контент"
  body: req.body.text 
    ? (req.body.text.length > 50 ? req.body.text.substring(0, 50) + '...' : req.body.text)
    : `${authorName} поделился фото/видео`,
  icon: 'https:/www./atomglide.com/1.png',
  data: {
    url: `https://www.atomglide.com/post/${post._id}`
  }
});

        subscribers.forEach(user => {
            webpush.sendNotification(user.pushSubscription, payload).catch(err => {
                if (err.statusCode === 410 || err.statusCode === 404) {
                    UserModel.findByIdAndUpdate(user._id, { pushSubscription: null }).exec();
                }
            });
        });
        // ------------------------------

        const populatedPost = await PostModel.findById(post._id).populate('user').exec();
        res.status(201).json(populatedPost);

    } catch (err) {
        console.error(err); // Этот лог выдал ошибку выше
        res.status(500).json({
            message: 'Не удалось создать пост',
            error: err.message
        });
    }
};

export const getAll = async (req, res) => {
    try {
        const posts = await PostModel.find()
            .populate('user', 'fullName avatarUrl profileUrl accountType atomProPlus verified')
            .populate('channelId', 'name nick')
            .exec();
            
        if (req.userId) {
            const user = await UserModel.findById(req.userId).select('favorites');
            const postsWithFavorites = posts.map(post => ({
                ...post.toObject(),
                isFavorite: user.favorites.some(favId => favId.equals(post._id))
            }));
            return res.json(postsWithFavorites);
        }

        res.json(posts);
    } catch (err) {
        console.error('Error getting posts:', err);
        res.status(500).json({ 
            message: 'Failed to get posts',
            error: err.message 
        });
    }
};


export const getOne = async (req, res) => {
    try {
        const postId = req.params.id;
        await ensureReactionStructure(postId);

        const post = await PostModel.findOneAndUpdate(
            { _id: postId },
            { $inc: { viewsCount: 1 } },
            { new: true }
        ).populate('user', 'fullName avatarUrl profileUrl')
         .populate('channelId', 'name nick');

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        let userReaction = null;
        let isFavorite = false;
        if (req.userId) {
            const user = await UserModel.findById(req.userId);
            
            if (post.likes.users.some(user => user.equals(req.userId))) {
                userReaction = 'like';
            } else if (post.dislikes.users.some(user => user.equals(req.userId))) {
                userReaction = 'dislike';
            }
            
            isFavorite = user.favorites.some(favId => favId.equals(post._id));
        }

        res.json({
            ...post.toObject(),
            userReaction,
            likesCount: post.likes.count,
            dislikesCount: post.dislikes.count,
            isFavorite
        });
    } catch (err) {
        console.error('Error getting post:', err);
        res.status(500).json({ 
            message: 'Failed to get post',
            error: err.message 
        });
    }
};


export const remove = async (req, res) => {
    try {
        const postId = req.params.id;
        const post = await PostModel.findById(postId);
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        if (post.user.toString() !== req.userId) {
            return res.status(403).json({ 
                message: 'Not authorized to delete this post',
                error: 'You can only delete your own posts'
            });
        }

        await PostModel.findByIdAndDelete(postId);
        await UserModel.updateMany(
            { favorites: postId },
            { $pull: { favorites: postId } }
        );

        await UserModel.findByIdAndUpdate(post.user, {
            $pull: { posts: postId },
            $push: {
                activityLog: {
                    action: 'post_deleted',
                    details: { postId, title: post.title }
                }
            }
        });

        res.json({ success: true, message: 'Post deleted successfully' });
    } catch (err) {
        console.error('Error deleting post:', err);
        res.status(500).json({ 
            message: 'Failed to delete post',
            error: err.message 
        });
    }
};


export const update = async (req, res) => {
    try {
        const postId = req.params.id;
        await PostModel.updateOne(
            { _id: postId },
            {
                title: req.body.title,
                imageUrl: req.body.imageUrl,
                user: req.userId,
            }
        );

        await UserModel.findByIdAndUpdate(req.userId, {
            $push: {
                activityLog: {
                    action: 'post_updated',
                    details: { postId }
                }
            }
        });

        res.json({ success: true, message: 'Post updated' });
    } catch (err) {
        console.error('Error updating post:', err);
        res.status(500).json({ 
            message: 'Failed to update post',
            error: err.message 
        });
    }
};


export const getPostsByUser = async (req, res) => {
    try {
        const posts = await PostModel.find({ user: req.params.userId })
            .populate('user', 'fullName avatarUrl profileUrl accountType atomProPlus verified')
            .exec();
            
        if (req.userId) {
            const user = await UserModel.findById(req.userId).select('favorites');
            const postsWithFavorites = posts.map(post => ({
                ...post.toObject(),
                isFavorite: user.favorites.some(favId => favId.equals(post._id))
            }));
            return res.json(postsWithFavorites);
        }

        res.json(posts);
    } catch (err) {
        console.error('Error getting user posts:', err);
        res.status(500).json({ 
            message: 'Failed to get user posts',
            error: err.message 
        });
    }
};




export const getPostsBySameTitle = async (req, res) => {
    try {
        const post = await PostModel.findById(req.params.id);
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        const posts = await PostModel.find({ 
            title: post.title,
            _id: { $ne: post._id }
        }).populate('user', 'fullName avatarUrl profileUrl');

        if (req.userId) {
            const user = await UserModel.findById(req.userId).select('favorites');
            const postsWithFavorites = posts.map(post => ({
                ...post.toObject(),
                isFavorite: user.favorites.some(favId => favId.equals(post._id))
            }));
            return res.json(postsWithFavorites);
        }

        res.json(posts);
    } catch (err) {
        console.error('Error getting similar posts:', err);
        res.status(500).json({ 
            message: 'Failed to get similar posts',
            error: err.message 
        });
    }
};



export const likePost = async (req, res) => {
    try {
        const postId = req.params.id;
        const userId = req.userId;

        // 1. Пытаемся добавить лайк только если пользователя еще НЕТ в массиве likes.users
        const updatedPost = await PostModel.findOneAndUpdate(
            { 
                _id: postId, 
                'likes.users': { $ne: userId } // Атомарная проверка: "не содержит этот ID"
            },
            {
                $addToSet: { 'likes.users': userId },
                $inc: { 'likes.count': 1 }
            },
            { new: true }
        ).populate('user', 'fullName avatarUrl profileUrl');

        // Если пост не найден или условие $ne не выполнилось (уже есть лайк)
        if (!updatedPost) {
            return res.status(400).json({ message: 'Пост не найден или вы уже поставили лайк' });
        }

        // 2. Если пользователь раньше ставил дизлайк — убираем его
        const wasDisliked = await PostModel.findOneAndUpdate(
            { _id: postId, 'dislikes.users': userId },
            {
                $pull: { 'dislikes.users': userId },
                $inc: { 'dislikes.count': -1 }
            },
            { new: true }
        );

        // 3. Логируем действие в профиль пользователя
        await UserModel.findByIdAndUpdate(userId, {
            $push: {
                activityLog: {
                    action: 'post_liked',
                    details: { postId, title: updatedPost.title || 'Untitled Post' }
                }
            }
        });

        res.json({
            success: true,
            post: wasDisliked || updatedPost, // Возвращаем актуальное состояние счетчиков
            likesCount: (wasDisliked || updatedPost).likes.count,
            dislikesCount: (wasDisliked || updatedPost).dislikes.count
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Ошибка при постановке лайка' });
    }
};

export const dislikePost = async (req, res) => {
    try {
        const postId = req.params.id;
        const userId = req.userId;

        const updatedPost = await PostModel.findOneAndUpdate(
            { 
                _id: postId, 
                'dislikes.users': { $ne: userId } 
            },
            {
                $addToSet: { 'dislikes.users': userId },
                $inc: { 'dislikes.count': 1 }
            },
            { new: true }
        ).populate('user', 'fullName avatarUrl profileUrl');

        if (!updatedPost) {
            return res.status(400).json({ message: 'Пост не найден или вы уже поставили дизлайк' });
        }

        const wasLiked = await PostModel.findOneAndUpdate(
            { _id: postId, 'likes.users': userId },
            {
                $pull: { 'likes.users': userId },
                $inc: { 'likes.count': -1 }
            },
            { new: true }
        );

        await UserModel.findByIdAndUpdate(userId, {
            $push: {
                activityLog: {
                    action: 'post_disliked',
                    details: { postId, title: updatedPost.title || 'Untitled Post' }
                }
            }
        });

        res.json({
            success: true,
            post: wasLiked || updatedPost,
            likesCount: (wasLiked || updatedPost).likes.count,
            dislikesCount: (wasLiked || updatedPost).dislikes.count
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Ошибка при постановке дизлайка' });
    }
};

export const removeReaction = async (req, res) => {
    try {
        const postId = req.params.id;
        const userId = req.userId;

        // Проверяем, где именно стоит реакция, и удаляем её атомарно
        const updatedPost = await PostModel.findOneAndUpdate(
            { _id: postId, $or: [{ 'likes.users': userId }, { 'dislikes.users': userId }] },
            {
                $pull: { 'likes.users': userId, 'dislikes.users': userId },
            },
            { new: true }
        ).populate('user', 'fullName avatarUrl profileUrl');

        if (!updatedPost) {
            return res.status(400).json({ message: 'Реакция не найдена' });
        }

        // Пересчитываем счетчики на основе длины массивов (самый надежный способ при удалении)
        updatedPost.likes.count = updatedPost.likes.users.length;
        updatedPost.dislikes.count = updatedPost.dislikes.users.length;
        await updatedPost.save();

        res.json({
            success: true,
            post: updatedPost,
            likesCount: updatedPost.likes.count,
            dislikesCount: updatedPost.dislikes.count
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Ошибка при удалении реакции' });
    }
};


export const checkUserReaction = async (req, res) => {
    try {
        const postId = req.params.id;
        const userId = req.userId;

        const post = await ensureReactionStructure(postId);
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        let reaction = null;
        if (post.likes.users.some(user => user.equals(userId))) {
            reaction = 'like';
        } else if (post.dislikes.users.some(user => user.equals(userId))) {
            reaction = 'dislike';
        }

        res.json({
            reaction,
            likesCount: post.likes.count,
            dislikesCount: post.dislikes.count
        });
    } catch (err) {
        console.error('Error checking user reaction:', err);
        res.status(500).json({ 
            message: 'Failed to check user reaction',
            error: err.message
        });
    }
};


export const addComment = async (req, res) => {
    try {
        const { text } = req.body;
         
        const userId = req.userId;

        const newComment = {
            text,
            user: userId,
            replies: [],
            parentComment: null,
        };

        const updatedPost = await PostModel.findByIdAndUpdate(
            postId,
            {
                $push: { comments: newComment },
                $inc: { commentsCount: 1 }
            },
            { new: true }
        ).populate('comments.user', 'fullName avatarUrl accountType atomProPlus verified');

        if (!updatedPost) {
            return res.status(404).json({ message: 'Post not found' });
        }

        const addedComment = updatedPost.comments[updatedPost.comments.length - 1];

        await UserModel.findByIdAndUpdate(userId, {
            $push: {
                activityLog: {
                    action: 'comment_added',
                    details: { postId, commentId: addedComment._id }
                }
            }
        });

        res.json(addedComment);
    } catch (err) {
        console.error('Error adding comment:', err);
        res.status(500).json({ 
            message: 'Failed to add comment',
            error: err.message 
        });
    }
};


export const addReply = async (req, res) => {
    try {
        const { text } = req.body;
        const postId = req.params.id;
        const commentId = req.params.commentId;
        const userId = req.userId;

        const newReply = {
            text,
            user: userId,
            replies: [],
            parentComment: commentId,
        };

        const post = await PostModel.findById(postId);
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        const updatedPost = await PostModel.findOneAndUpdate(
            { _id: postId, 'comments._id': commentId },
            {
                $push: { 
                    'comments.$.replies': new mongoose.Types.ObjectId(),
                    comments: newReply 
                },
                $inc: { commentsCount: 1 }
            },
            { new: true }
        ).populate('comments.user', 'fullName avatarUrl accountType atomProPlus verified')
         .populate('comments.replies.user', 'fullName avatarUrl accountType atomProPlus verified');

        if (!updatedPost) {
            return res.status(404).json({ message: 'Comment not found' });
        }

        const addedReply = updatedPost.comments.find(c => 
            c.parentComment && c.parentComment.toString() === commentId
        );

        await PostModel.updateOne(
            { _id: postId, 'comments._id': commentId },
            { $push: { 'comments.$.replies': addedReply._id } }
        );

        await UserModel.findByIdAndUpdate(userId, {
            $push: {
                activityLog: {
                    action: 'comment_reply_added',
                    details: { postId, commentId, replyId: addedReply._id }
                }
            }
        });

        res.json(addedReply);
    } catch (err) {
        console.error('Error adding reply:', err);
        res.status(500).json({ 
            message: 'Failed to add reply',
            error: err.message 
        });
    }
};


export const getComments = async (req, res) => {
    try {
        const postId = req.params.id;
        const post = await PostModel.findById(postId)
            .select('comments')
            .populate('comments.user', 'fullName avatarUrl accountType atomProPlus verified')
            .populate({
                path: 'comments.replies',
                populate: {
                    path: 'user',
                    select: 'fullName avatarUrl accountType atomProPlus verified'
                }
            });

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        const rootComments = post.comments.filter(comment => !comment.parentComment);

        res.json(rootComments);
    } catch (err) {
        console.error('Error getting comments:', err);
        res.status(500).json({ 
            message: 'Failed to get comments',
            error: err.message 
        });
    }
};


export const getCommentsCount = async (req, res) => {
    try {
        const postId = req.params.id;
        const post = await PostModel.findById(postId).select('commentsCount');

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        res.json({ count: post.commentsCount });
    } catch (err) {
        console.error('Error getting comments count:', err);
        res.status(500).json({ 
            message: 'Failed to get comments count',
            error: err.message 
        });
    }
};


export const deleteComment = async (req, res) => {
    try {
        const postId = req.params.id;
        const commentId = req.params.commentId;
        const userId = req.userId;

        const post = await PostModel.findById(postId);
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        const comment = post.comments.id(commentId);
        if (!comment) {
            return res.status(404).json({ message: 'Comment not found' });
        }

        if (comment.user.toString() !== userId) {
            return res.status(403).json({ message: 'Not authorized to delete this comment' });
        }

        const repliesToDelete = comment.replies;
        
        await PostModel.findByIdAndUpdate(postId, {
            $pull: { 
                comments: { 
                    $or: [
                        { _id: commentId },
                        { _id: { $in: repliesToDelete } }
                    ]
                } 
            },
            $inc: { commentsCount: -1 - repliesToDelete.length }
        });

        await UserModel.findByIdAndUpdate(userId, {
            $push: {
                activityLog: {
                    action: 'comment_deleted',
                    details: { postId, commentId }
                }
            }
        });

        res.json({ success: true, message: 'Comment deleted' });
    } catch (err) {
        console.error('Error deleting comment:', err);
        res.status(500).json({ 
            message: 'Failed to delete comment',
            error: err.message 
        });
    }
};



export const PS = {
    create,
    getAll,
    getOne,
    remove,
    update,
    getPostsByUser,
    getPostsBySameTitle,
    likePost,
    dislikePost,
    removeReaction,
    checkUserReaction,
    addComment,
    addReply,
    getComments,
    getCommentsCount,
    deleteComment
};
