import Chat from '../models/chat.js';
import Message from '../models/message.js';
import Notification from '../models/notification.js';
import UserModel from '../models/user.js';
import { encryptText, decryptText, generateChatEncryptionKey } from '../utils/encryption.js';


export const createChat = async (req, res) => {
  try {
    const { participants, type = 'private', name, description } = req.body;
    const userId = req.userId;

    if (!participants || participants.length === 0) {
      return res.status(400).json({ error: 'Участники обязательны' });
    }

    
    const allParticipants = [...new Set([userId, ...participants])];

    
    if (type === 'private' && allParticipants.length === 2) {
      const existingChat = await Chat.findOne({
        type: 'private',
        participants: { $all: allParticipants, $size: 2 }
      });

      if (existingChat) {
        return res.json({ chat: existingChat, isNew: false });
      }
    }

    
    const chat = new Chat({
      participants: allParticipants,
      type,
      name: type === 'group' ? name : undefined,
      description: type === 'group' ? description : undefined,
      createdBy: userId,
      encryptionKeys: [{ key: generateChatEncryptionKey() }]
    });

    await chat.save();
    await chat.populate('participants', 'username fullName avatarUrl');

    res.json({ chat, isNew: true });
  } catch (error) {
    console.error('Ошибка создания чата:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const createChatByUsername = async (req, res) => {
  try {
    console.log('=== createChatByUsername вызвана ===');
    console.log('req.body:', req.body);
    console.log('req.userId:', req.userId);
    
    const { username } = req.body;
    const userId = req.userId;

    if (!username) {
      return res.status(400).json({ error: 'Никнейм обязателен' });
    }

    
    console.log('Ищем пользователя с никнеймом:', username);
    const targetUser = await UserModel.findOne({ username });
    console.log('Найденный пользователь:', targetUser ? 'найден' : 'не найден');
    
    if (!targetUser) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }

    if (targetUser._id.toString() === userId) {
      return res.status(400).json({ error: 'Нельзя создать чат с самим собой' });
    }

    
    console.log('Проверяем существующий чат...');
    const existingChat = await Chat.findOne({
      type: 'private',
      participants: { $all: [userId, targetUser._id], $size: 2 }
    });
    console.log('Существующий чат:', existingChat ? 'найден' : 'не найден');

    if (existingChat) {
      await existingChat.populate('participants', 'username fullName avatarUrl');
      return res.json({ chat: existingChat, isNew: false });
    }

    
    console.log('Создаем новый чат...');
    console.log('userId:', userId);
    console.log('targetUser._id:', targetUser._id);
    
    const encryptionKey = generateChatEncryptionKey();
    console.log('Сгенерированный ключ:', encryptionKey);
    
    const chat = new Chat({
      participants: [userId, targetUser._id],
      type: 'private',
      createdBy: userId,
      encryptionKeys: [{ key: encryptionKey }]
    });
    console.log('Чат создан в памяти:', chat);

    await chat.save();
    console.log('Чат сохранен в БД');
    await chat.populate('participants', 'username fullName avatarUrl');
    console.log('Чат заполнен данными участников');

    res.json({ chat, isNew: true });
  } catch (error) {
    console.error('Ошибка создания чата по никнейму:', error);
    console.error('Детали ошибки:', {
      message: error.message,
      stack: error.stack,
      username,
      userId
    });
    res.status(500).json({ 
      error: 'Ошибка сервера',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};


export const getUserChats = async (req, res) => {
  try {
    const userId = req.userId;
    const { page = 1, limit = 20 } = req.query;

    const chats = await Chat.find({
      participants: userId,
      isActive: true
    })
    .populate('participants', 'username fullName avatarUrl')
    .populate('lastMessage')
    .sort({ lastMessageTime: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit);

    res.json(chats);
  } catch (error) {
    console.error('Ошибка получения чатов:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const getChatMessages = async (req, res) => {
  try {
    const { chatId } = req.params;
    const userId = req.userId;
    const { page = 1, limit = 50 } = req.query;

    
    const chat = await Chat.findOne({
      _id: chatId,
      participants: userId
    });

    if (!chat) {
      return res.status(403).json({ error: 'Нет доступа к этому чату' });
    }

    const messages = await Message.find({
      chat: chatId,
      deleted: false
    })
    .populate('sender', 'username fullName avatarUrl')
    .populate('replyTo')
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit);

    
    const decryptedMessages = messages.map(msg => {
      try {
        const decryptedContent = decryptText(msg.encryptedContent);
        return {
          ...msg.toObject(),
          content: decryptedContent
        };
      } catch (error) {
        console.error('Ошибка расшифровки сообщения:', error);
        return {
          ...msg.toObject(),
          content: '[Сообщение не удалось расшифровать]'
        };
      }
    });

    res.json(decryptedMessages.reverse());
  } catch (error) {
    console.error('Ошибка получения сообщений:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const sendMessage = async (req, res) => {
  try {
    const { chatId, content, replyTo, messageType = 'text' } = req.body;
    const userId = req.userId;

    
    const chat = await Chat.findOne({
      _id: chatId,
      participants: userId
    });

    if (!chat) {
      return res.status(403).json({ error: 'Нет доступа к этому чату' });
    }

    
    const encryptedContent = encryptText(content);
    const encryptionKey = chat.encryptionKeys[chat.encryptionKeys.length - 1];

    
    const message = new Message({
      chat: chatId,
      sender: userId,
      content,
      encryptedContent,
      messageType,
      replyTo,
      encryptionKey
    });

    await message.save();

    
    chat.lastMessage = message._id;
    chat.lastMessageTime = new Date();
    await chat.save();

    
    const otherParticipants = chat.participants.filter(p => p.toString() !== userId);
    
    for (const participantId of otherParticipants) {
      await Notification.create({
        user: participantId,
        type: 'message',
        title: 'Новое сообщение',
        content: `Вам пришло новое сообщение в чате`,
        relatedChat: chatId,
        relatedMessage: message._id,
        relatedUser: userId
      });
    }

    await message.populate('sender', 'username fullName avatarUrl');
    await message.populate('replyTo');

    res.json({
      ...message.toObject(),
      content 
    });
  } catch (error) {
    console.error('Ошибка отправки сообщения:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const markAsRead = async (req, res) => {
  try {
    const { chatId } = req.params;
    const userId = req.userId;

    
    const chat = await Chat.findOne({
      _id: chatId,
      participants: userId
    });

    if (!chat) {
      return res.status(403).json({ error: 'Нет доступа к этому чату' });
    }

    
    await Message.updateMany(
      {
        chat: chatId,
        sender: { $ne: userId },
        isRead: false
      },
      {
        $set: { isRead: true },
        $push: {
          readBy: {
            user: userId,
            readAt: new Date()
          }
        }
      }
    );

    
    await Notification.deleteMany({
      user: userId,
      relatedChat: chatId,
      type: 'message'
    });

    res.json({ success: true });
  } catch (error) {
    console.error('Ошибка отметки как прочитанное:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const getNotifications = async (req, res) => {
  try {
    const userId = req.userId;
    const { page = 1, limit = 20 } = req.query;

    const notifications = await Notification.find({ user: userId })
      .populate('relatedUser', 'username fullName avatarUrl')
      .populate('relatedChat')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    res.json(notifications);
  } catch (error) {
    console.error('Ошибка получения уведомлений:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const markNotificationsAsRead = async (req, res) => {
  try {
    const userId = req.userId;
    const { notificationIds } = req.body;

    if (notificationIds && notificationIds.length > 0) {
      await Notification.updateMany(
        { _id: { $in: notificationIds }, user: userId },
        { isRead: true, readAt: new Date() }
      );
    } else {
      await Notification.updateMany(
        { user: userId },
        { isRead: true, readAt: new Date() }
      );
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Ошибка отметки уведомлений:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const deleteChat = async (req, res) => {
  try {
    const { chatId } = req.params;
    const userId = req.userId;

    const chat = await Chat.findOne({
      _id: chatId,
      participants: userId
    });

    if (!chat) {
      return res.status(403).json({ error: 'Нет доступа к этому чату' });
    }

    
    if (chat.type === 'group' && chat.createdBy.toString() !== userId) {
      return res.status(403).json({ error: 'Только создатель может удалить групповой чат' });
    }

    
    if (chat.type === 'private') {
      chat.isActive = false;
      await chat.save();
    } else {
      
      await Chat.findByIdAndDelete(chatId);
      await Message.deleteMany({ chat: chatId });
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Ошибка удаления чата:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

