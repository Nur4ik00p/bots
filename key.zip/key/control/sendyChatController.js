import SendyChat from '../models/sendyChat.js';
import UserModel from '../models/user.js';
import { encryptText, decryptText, generateChatEncryptionKey } from '../utils/encryption.js';


export const createChat = async (req, res) => {
  try {
    let { username } = req.body;
    const currentUserId = req.userId;

    if (!username) {
      return res.status(400).json({ error: 'Никнейм обязателен' });
    }

    if (!username.startsWith('@')) username = `@${username}`;

    const currentUser = await UserModel.findById(currentUserId);
    const targetUser = await UserModel.findOne({ username });

    if (!targetUser) return res.status(404).json({ error: 'Пользователь не найден' });
    if (targetUser._id.toString() === currentUserId) {
      return res.status(400).json({ error: 'Нельзя создать чат с самим собой' });
    }

    
    const existingChat = await SendyChat.findOne({
      isActive: true,
      $and: [
        { 'participants.userId': currentUserId },
        { 'participants.userId': targetUser._id }
      ]
    });

    if (existingChat) {
      return res.json({ chat: existingChat, isNew: false });
    }

    
    const encryptionKey = generateChatEncryptionKey();
    const newChat = new SendyChat({
      participants: [
        {
          userId: currentUser._id,
          username: currentUser.username,
          fullName: currentUser.fullName,
          avatarUrl: currentUser.avatarUrl || '',
          displayName: targetUser.fullName 
        },
        {
          userId: targetUser._id,
          username: targetUser.username,
          fullName: targetUser.fullName,
          avatarUrl: targetUser.avatarUrl || '',
          displayName: currentUser.fullName 
        }
      ],
      messages: [],
      encryptionKey
    });

    await newChat.save();
    console.log('✅ Новый чат создан:', newChat._id);
    console.log('👥 Участники:', newChat.participants.map(p => p.displayName));

    res.json({ chat: newChat, isNew: true });
  } catch (error) {
    console.error('❌ Ошибка при создании чата:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const getUserChats = async (req, res) => {
  try {
    const currentUserId = req.userId;

    // Быстрый запрос - только нужные поля, без загрузки всех сообщений
    const chats = await SendyChat.find({
      'participants.userId': currentUserId,
      isActive: true
    })
    .select('participants lastMessage updatedAt createdAt')
    .sort({ 'lastMessage.createdAt': -1 })
    .lean();

    // Формируем ответ с актуальными аватарками и обрезанным превью
    const MAX_PREVIEW_LENGTH = 50;
    
    const chatsFormatted = chats.map(chat => {
      // Находим собеседника
      const otherParticipant = chat.participants.find(
        p => p.userId.toString() !== currentUserId
      );
      
      // Обрезаем превью последнего сообщения
      let lastMessagePreview = chat.lastMessage?.content || '';
      if (lastMessagePreview.length > MAX_PREVIEW_LENGTH) {
        lastMessagePreview = lastMessagePreview.substring(0, MAX_PREVIEW_LENGTH) + '...';
      }
      
      return {
        _id: chat._id,
        participant: {
          _id: otherParticipant?.userId,
          username: otherParticipant?.username,
          fullName: otherParticipant?.fullName,
          avatarUrl: otherParticipant?.avatarUrl || ''
        },
        lastMessage: {
          content: lastMessagePreview,
          senderId: chat.lastMessage?.senderId,
          createdAt: chat.lastMessage?.createdAt
        },
        updatedAt: chat.updatedAt,
        unreadCount: 0 // TODO: считать отдельным запросом если нужно
      };
    });

    res.json(chatsFormatted);
  } catch (error) {
    console.error('❌ Ошибка при получении чатов:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const getChatMessages = async (req, res) => {
  try {
    const { chatId } = req.params;
    const currentUserId = req.userId;

    const chat = await SendyChat.findById(chatId);
    if (!chat || !chat.participants.some(p => p.userId.toString() === currentUserId)) {
      return res.status(403).json({ error: 'Нет доступа к этому чату' });
    }

    
    const decryptedMessages = chat.messages.map(msg => {
      let content = '[Не удалось расшифровать сообщение]';
      try {
        content = decryptText(msg.encryptedContent);
      } catch (e) {
        console.error(`Ошибка расшифровки сообщения ${msg._id}:`, e.message);
      }

      const senderParticipant = chat.participants.find(
        p => p.userId.toString() === msg.senderId.toString()
      );

      const sender = senderParticipant
        ? {
            _id: senderParticipant.userId,
            username: senderParticipant.username,
            fullName: senderParticipant.fullName,
            avatarUrl: senderParticipant.avatarUrl || ''
          }
        : null;

      return { ...msg.toObject(), content, sender };
    });

    res.json(decryptedMessages);
  } catch (error) {
    console.error('Ошибка при получении сообщений чата:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const sendMessage = async (req, res) => {
  try {
    const { chatId } = req.params;
    const { content, replyTo, messageType = 'text' } = req.body;
    const currentUserId = req.userId;

    const chat = await SendyChat.findById(chatId);
    if (!chat || !chat.participants.some(p => p.userId.toString() === currentUserId)) {
      return res.status(403).json({ error: 'Нет доступа к этому чату' });
    }

    const encryptionKey = generateChatEncryptionKey();
    const encryptedContent = encryptText(content);

    const newMessage = {
      senderId: currentUserId,
      content,
      encryptedContent,
      messageType,
      replyTo,
      encryptionKey,
      createdAt: new Date()
    };

    chat.messages.push(newMessage);
    chat.lastMessage = {
      content,
      senderId: currentUserId,
      createdAt: new Date()
    };

    await chat.save();

    const senderParticipant = chat.participants.find(
      p => p.userId.toString() === currentUserId
    );

    const senderInfo = senderParticipant
      ? {
          _id: senderParticipant.userId,
          username: senderParticipant.username,
          fullName: senderParticipant.fullName,
          avatarUrl: senderParticipant.avatarUrl || ''
        }
      : null;

    const savedMessage = {
      ...newMessage,
      _id: chat.messages[chat.messages.length - 1]._id,
      sender: senderInfo
    };

    res.status(201).json({ message: 'Сообщение отправлено', message: savedMessage });
  } catch (error) {
    console.error('Ошибка при отправке сообщения:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const markAsRead = async (req, res) => {
  try {
    const { chatId } = req.params;
    const currentUserId = req.userId;

    const chat = await SendyChat.findById(chatId);
    if (!chat || !chat.participants.some(p => p.userId.toString() === currentUserId)) {
      return res.status(403).json({ error: 'Нет доступа к этому чату' });
    }

    chat.messages.forEach(msg => {
      if (msg.senderId.toString() !== currentUserId && !msg.isRead) {
        msg.isRead = true;
        msg.readBy.push({ userId: currentUserId, readAt: new Date() });
      }
    });

    await chat.save();
    res.json({ message: 'Сообщения отмечены как прочитанные' });
  } catch (error) {
    console.error('Ошибка при отметке сообщений как прочитанных:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};


export const deleteChat = async (req, res) => {
  try {
    const { chatId } = req.params;
    const currentUserId = req.userId;

    const chat = await SendyChat.findById(chatId);
    if (!chat || !chat.participants.some(p => p.userId.toString() === currentUserId)) {
      return res.status(403).json({ error: 'Нет доступа к этому чату' });
    }

    chat.isActive = false;
    await chat.save();

    res.json({ message: 'Чат удален' });
  } catch (error) {
    console.error('Ошибка при удалении чата:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};
