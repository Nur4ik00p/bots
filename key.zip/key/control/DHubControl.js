import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { validationResult } from 'express-validator';
import DHubUserModel from '../models/DHubUsers.js';

const JWT_SECRET = "isdghfiuhywrg6";
const registrationTimestamps = new Map();

function generateRandomLogin() {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let result = '';
  for (let i = 0; i < 5; i++) {
    result += letters.charAt(Math.floor(Math.random() * letters.length));
  }
  return result;
}

export const registerhub = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    
    const ip = req.headers['x-forwarded-for']?.split(',')[0] || req.connection.remoteAddress;
    const now = Date.now();
    const last = registrationTimestamps.get(ip);
    if (last && now - last < 5 * 60 * 1000) {
      return res.status(429).json({ message: 'Регистрация с этого IP возможна раз в 5 минут.' });
    }

    const {
      password,
      gender,
      email,
      country,
      atomNick,
      programmingLanguage,
      educationInstitution,
      projectsPosition
    } = req.body;

    if (!programmingLanguage) {
      return res.status(400).json({ message: 'Укажите язык программирования' });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const dhubUser = new DHubUserModel({
      login: generateRandomLogin(),
      passwordHash,
      gender,
      email,
      country,
      atomNick,
      programmingLanguage,
      educationInstitution,
      projectsPosition,
      tokensCount: 100,
      premium: false
    });

    await dhubUser.save();
    registrationTimestamps.set(ip, now);

    const token = jwt.sign({ _id: dhubUser._id }, JWT_SECRET, { expiresIn: '30d' });

    res.status(201).json({ dhubUser, token });

  } catch (err) {
    console.error('DHub registration error:', err);
    res.status(500).json({
      message: 'DHub registration failed',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};

export const loginhub = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { loginOrEmail, password } = req.body;

    if (!loginOrEmail || !password) {
      return res.status(400).json({ message: 'Укажите login/email и пароль' });
    }

    
    const dhubUser = await DHubUserModel.findOne({
      $or: [
        { login: loginOrEmail },
        { email: loginOrEmail }
      ]
    });

    if (!dhubUser) {
      return res.status(400).json({ message: 'Пользователь не найден' });
    }

    
    const isPasswordValid = await bcrypt.compare(password, dhubUser.passwordHash);
    if (!isPasswordValid) {
      return res.status(400).json({ message: 'Неверный пароль' });
    }

    
    const token = jwt.sign({ _id: dhubUser._id }, JWT_SECRET, { expiresIn: '30d' });

    res.status(200).json({
      dhubUser,
      token
    });

  } catch (err) {
    console.error('DHub login error:', err);
    res.status(500).json({
      message: 'DHub login failed',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};

export const dhub = { registerhub, loginhub };
