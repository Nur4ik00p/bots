import SupportTicket from '../models/supportTicket.js';
import AdminSession from '../models/adminSession.js';
import UserModel from '../models/user.js';
import jwt from 'jsonwebtoken';

const ADMIN_PASSWORD = 'KullCat1223';
const ADMIN_USERNAME = 'jpegweb';
const MAX_ATTEMPTS = 5;
const BLOCK_DURATION_HOURS = 24;

export const createTicket = async (req, res) => {
  try {
    const { name, nickname, type, message } = req.body;
    
    if (!name || !nickname || !type || !message) {
      return res.status(400).json({ error: 'Все поля обязательны' });
    }

    const user = await UserModel.findOne({ username: nickname.replace('@', '') }).lean();
    
    const ticket = new SupportTicket({
      name,
      nickname: nickname.replace('@', ''),
      type,
      message,
      userId: user?._id || null,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    await ticket.save();

    res.status(201).json({ 
      success: true, 
      message: 'Обращение успешно отправлено',
      ticketId: ticket._id 
    });
  } catch (err) {
    console.error('Error creating ticket:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

export const adminLogin = async (req, res) => {
  try {
    const { username, password } = req.body;
    const ip = req.ip;

    let session = await AdminSession.findOne({ ipAddress: ip });
    
    if (!session) {
      session = new AdminSession({ ipAddress: ip });
    }

    if (session.isBlocked && session.blockedUntil > new Date()) {
      const remainingTime = Math.ceil((session.blockedUntil - new Date()) / (1000 * 60 * 60));
      return res.status(403).json({ 
        error: `Доступ заблокирован. Осталось ${remainingTime} часов`,
        blocked: true 
      });
    }

    if (session.isBlocked && session.blockedUntil <= new Date()) {
      session.isBlocked = false;
      session.failedAttempts = 0;
      session.blockedUntil = null;
    }

    const user = await UserModel.findOne({ username: ADMIN_USERNAME }).lean();
    
    if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
      session.failedAttempts += 1;
      session.lastAttempt = new Date();
      
      if (session.failedAttempts >= MAX_ATTEMPTS) {
        session.isBlocked = true;
        session.blockedUntil = new Date(Date.now() + BLOCK_DURATION_HOURS * 60 * 60 * 1000);
        await session.save();
        return res.status(403).json({ 
          error: 'Превышено количество попыток. Доступ заблокирован на 24 часа',
          blocked: true 
        });
      }
      
      await session.save();
      return res.status(401).json({ 
        error: 'Неверные учетные данные',
        attemptsLeft: MAX_ATTEMPTS - session.failedAttempts 
      });
    }

    session.failedAttempts = 0;
    session.isBlocked = false;
    session.blockedUntil = null;
    await session.save();

    const token = jwt.sign(
      { admin: true, username: ADMIN_USERNAME, userId: user?._id },
      process.env.JWT_SECRET || 'isdghfiuhywrg6',
      { expiresIn: '8h' }
    );

    res.json({ success: true, token });
  } catch (err) {
    console.error('Admin login error:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

export const checkAdminAuth = (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ error: 'Токен не предоставлен' });
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'isdghfiuhywrg6');
    if (!decoded.admin) {
      return res.status(403).json({ error: 'Нет прав администратора' });
    }
    
    req.adminId = decoded.userId;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Неверный токен' });
  }
};

export const getTickets = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const query = status ? { status } : {};
    
    const [tickets, total] = await Promise.all([
      SupportTicket.find(query)
        .populate('userId', 'fullName username avatarUrl')
        .populate('respondedBy', 'fullName username')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(parseInt(limit))
        .lean(),
      SupportTicket.countDocuments(query)
    ]);

    res.json({
      tickets,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / limit)
    });
  } catch (err) {
    console.error('Get tickets error:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

export const getStats = async (req, res) => {
  try {
    const [total, pending, inProgress, resolved, rejected, users, posts] = await Promise.all([
      SupportTicket.countDocuments(),
      SupportTicket.countDocuments({ status: 'pending' }),
      SupportTicket.countDocuments({ status: 'in_progress' }),
      SupportTicket.countDocuments({ status: 'resolved' }),
      SupportTicket.countDocuments({ status: 'rejected' }),
      UserModel.countDocuments(),
      (await import('../models/post.js')).default.countDocuments()
    ]);

    const byType = await SupportTicket.aggregate([
      { $group: { _id: '$type', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      tickets: { total, pending, inProgress, resolved, rejected },
      byType,
      users,
      posts
    });
  } catch (err) {
    console.error('Get stats error:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

export const respondToTicket = async (req, res) => {
  try {
    const { id } = req.params;
    const { response, status } = req.body;

    if (!response) {
      return res.status(400).json({ error: 'Ответ обязателен' });
    }

    const ticket = await SupportTicket.findById(id);
    if (!ticket) {
      return res.status(404).json({ error: 'Обращение не найдено' });
    }

    ticket.response = response;
    ticket.status = status || 'resolved';
    ticket.respondedAt = new Date();
    ticket.respondedBy = req.adminId;
    await ticket.save();

    if (ticket.userId) {
      const user = await UserModel.findById(ticket.userId);
      if (user) {
        user.noth = user.noth || [];
        user.noth.push({
          date: new Date(),
          title: 'Ответ на обращение',
          description: `Ваше обращение "${ticket.type}" получило ответ: ${response.substring(0, 100)}...`
        });
        await user.save();
      }
    }

    res.json({ success: true, ticket });
  } catch (err) {
    console.error('Respond to ticket error:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

export const getUserTickets = async (req, res) => {
  try {
    const userId = req.userId;
    const user = await UserModel.findById(userId).lean();
    
    if (!user) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }

    const tickets = await SupportTicket.find({ 
      $or: [
        { userId: userId },
        { nickname: user.username }
      ]
    })
    .sort({ createdAt: -1 })
    .lean();

    res.json(tickets);
  } catch (err) {
    console.error('Get user tickets error:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

export const checkBlockStatus = async (req, res) => {
  try {
    const ip = req.ip;
    const session = await AdminSession.findOne({ ipAddress: ip }).lean();
    
    if (session?.isBlocked && session.blockedUntil > new Date()) {
      const remainingTime = Math.ceil((session.blockedUntil - new Date()) / (1000 * 60 * 60));
      return res.json({ blocked: true, remainingHours: remainingTime });
    }
    
    res.json({ blocked: false, attemptsLeft: MAX_ATTEMPTS - (session?.failedAttempts || 0) });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};
