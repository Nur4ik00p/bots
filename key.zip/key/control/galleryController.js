import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import PostModel from '../models/post.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const getPhotos = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 30, 100);
    const skip = (page - 1) * limit;

    const [posts, total] = await Promise.all([
      PostModel.find({ 
        imageUrl: { $exists: true, $ne: null, $ne: '' },
        mediaType: { $in: ['image', null, undefined] }
      })
        .select('imageUrl title viewsCount user createdAt')
        .populate('user', 'username fullName avatarUrl')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      PostModel.countDocuments({ 
        imageUrl: { $exists: true, $ne: null, $ne: '' },
        mediaType: { $in: ['image', null, undefined] }
      })
    ]);

    const photos = posts.map(post => ({
      _id: post._id,
      url: post.imageUrl,
      title: post.title,
      views: post.viewsCount,
      author: post.user,
      createdAt: post.createdAt
    }));

    res.json({
      photos,
      total,
      page,
      totalPages: Math.ceil(total / limit),
      hasMore: page * limit < total
    });
  } catch (err) {
    console.error('Get photos error:', err);
    res.status(500).json({ error: 'Ошибка получения фотографий' });
  }
};

export const getVideos = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 50);
    const skip = (page - 1) * limit;

    const [posts, total] = await Promise.all([
      PostModel.find({ 
        videoUrl: { $exists: true, $ne: null, $ne: '' },
        mediaType: 'video'
      })
        .select('videoUrl videoDuration title viewsCount user createdAt')
        .populate('user', 'username fullName avatarUrl')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      PostModel.countDocuments({ 
        videoUrl: { $exists: true, $ne: null, $ne: '' },
        mediaType: 'video'
      })
    ]);

    const videos = posts.map(post => ({
      _id: post._id,
      url: post.videoUrl,
      duration: post.videoDuration,
      title: post.title,
      views: post.viewsCount,
      author: post.user,
      createdAt: post.createdAt
    }));

    res.json({
      videos,
      total,
      page,
      totalPages: Math.ceil(total / limit),
      hasMore: page * limit < total
    });
  } catch (err) {
    console.error('Get videos error:', err);
    res.status(500).json({ error: 'Ошибка получения видео' });
  }
};

export const getGalleryStats = async (req, res) => {
  try {
    const [photosCount, videosCount] = await Promise.all([
      PostModel.countDocuments({ 
        imageUrl: { $exists: true, $ne: null, $ne: '' },
        mediaType: { $in: ['image', null, undefined] }
      }),
      PostModel.countDocuments({ 
        videoUrl: { $exists: true, $ne: null, $ne: '' },
        mediaType: 'video'
      })
    ]);

    res.json({ photosCount, videosCount });
  } catch (err) {
    console.error('Get gallery stats error:', err);
    res.status(500).json({ error: 'Ошибка получения статистики' });
  }
};
