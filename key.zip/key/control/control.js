import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { validationResult } from 'express-validator';
import fs from 'fs';
import { registerValidation, loginValidation } from '../validations/auth.js';
import UserModel from '../models/user.js';
import PostModel from '../models/post.js';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import path from 'path';
import { FORBIDDEN_USERNAMES } from '../utils/forbidden-usernames.js';
import mongoose from 'mongoose'; 
import crypto from 'crypto';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const JWT_SECRET = "isdghfiuhywrg6";
const captchaStore = new Map(); 
import NftProductModel from "../models/nftProduct.js";

export const getUserPurchases = async (req, res) => {
  try {
    const userId = req.params.id;
    const user = await UserModel.findById(userId).populate('purchases');
    if (!user) return res.status(404).json({ message: "Пользователь не найден" });

    res.json(user.purchases || []);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Ошибка при получении покупок", error: err.message });
  }
};
export const getCaptcha = (req, res) => {
  
  const a = Math.floor(Math.random() * 10) + 1;
  const b = Math.floor(Math.random() * 10) + 1;
  const answer = a + b;
  const key = crypto.randomBytes(16).toString('hex');
  captchaStore.set(key, { answer, expires: Date.now() + 5 * 60 * 1000 });
  res.json({ key, question: `${a} + ${b} = ?` });
};

export const verifyAndRefreshToken = async (req, res, next) => {
  try {
    const token = req.cookies.token || req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ message: "Токен отсутствует" });

    
    const decoded = jwt.verify(token, "isdghfiuhywrg6"); 

    
    const user = await UserModel.findById(decoded._id);
    if (!user) return res.status(401).json({ message: "Пользователь не найден" });

    
    if (decoded.tokenVersion !== user.tokenVersion) {
      console.log(`вќЊ Несовпадение версии токена: токен=${decoded.tokenVersion}, бд=${user.tokenVersion}`);
      return res.status(401).json({ message: "Токен устарел" });
    }

    next();
  } catch (err) {
    console.error("Ошибка проверки токена:", err.message);
    return res.status(401).json({ message: "Недействительный токен" });
  }
};



export const login = async (req, res) => {
  try {
    const identifier = req.body.username.trim();

    const user = await UserModel.findOne({
      $or: [
        { username: identifier },
        { username: `@${identifier}` },
        { fullName: { $regex: new RegExp(`^${identifier}$`, 'i') } }
      ]
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const isValidPass = await bcrypt.compare(req.body.password, user._doc.passwordHash);
    if (!isValidPass) {
      return res.status(400).json({ message: 'Invalid password' });
    }

    
    const updatedUser = await UserModel.findByIdAndUpdate(
      user._id,
      { $inc: { tokenVersion: 1 } },
      { new: true }
    );

    
    const token = jwt.sign(
      {
        _id: updatedUser._id,
        tokenVersion: updatedUser.tokenVersion
      },
      "isdghfiuhywrg6",
      { expiresIn: '30d' }
    );


    
    res.json({
      ...updatedUser.toObject(),
      passwordHash: undefined,
      token
    });

  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ 
      message: 'Login failed',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};


const registrationTimestamps = new Map(); 
// Добавьте этот импорт в начало файла control.js, если его там нет
import ChannelModel from '../models/channel.js';

// ... существующий код ...

export const register = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const ip = req.headers['x-forwarded-for']?.split(',')[0] || req.connection.remoteAddress;
        const now = Date.now();
        const last = registrationTimestamps.get(ip);
        if (last && now - last < 5 * 60 * 1000) {
            return res.status(429).json({ message: 'Регистрация с этого IP возможна раз в 5 минут. Попробуйте позже.' });
        }

        const { username, password, fullName, about, theme, socialMedia } = req.body;
        
        const existingUser = await UserModel.findOne({ username });
        if (existingUser) {
            return res.status(400).json({
                message: 'Username already exists',
            });
        }

        const hashedPassword = await bcrypt.hash(password, 12);

        const status = (typeof req.body.status === 'string' && [...req.body.status].length === 1) ? req.body.status : '😜';
        const newUser = new UserModel({
            username,
            passwordHash: hashedPassword,
            fullName,
            about: about || '',
            theme: theme || 'dark',
            status,
            service:['AtomGlide','AtomGlide Messanger','AtomGlide Music'],
            socialMedia: socialMedia || {},
            avatarUrl: req.files?.avatar ? `/uploads/${req.files.avatar[0].filename}` : null,
            coverUrl: req.files?.cover ? `/uploads/${req.files.cover[0].filename}` : null,
            awards: [{
              date: new Date(),
              title: 'Добро пожаловать!',
              description: 'Награда за успешную регистрацию',
              issuedBy: null
            }]
        });

        // Сохраняем пользователя
        const user = await newUser.save();

        // --- ЛОГИКА СОЗДАНИЯ КАНАЛА ---
        try {
            const defaultChannel = new ChannelModel({
                name: `Канал ${user.fullName || user.username}`,
                // Убираем пробелы и приводим к нижнему регистру, добавляем $ согласно логике channels.js
                nick: `$${user.username.replace(/\s+/g, '').toLowerCase()}`,
                description: `Официальный канал пользователя ${user.fullName}`,
                owner: user._id,
                avatarUrl: user.avatarUrl || '', // Копируем аватар пользователя если есть
            });
            await defaultChannel.save();
            console.log(`✅ Создан базовый канал для пользователя: ${user.username}`);
        } catch (channelErr) {
            console.error('⚠️ Ошибка при создании автоматического канала:', channelErr);
            // Мы не прерываем регистрацию, если упало создание канала, 
            // но вы можете добавить return res.status(500) если это критично
        }
        // ------------------------------

        registrationTimestamps.set(ip, now);

        const token = jwt.sign(
            { _id: user._id },
            'isdghfiuhywrg6',
            { expiresIn: '30d' }
        );

        res.status(201).json({
            ...user.toObject(),
            passwordHash: undefined,
            token
        });

    } catch (err) {
        console.error('Registration error:', err);
        res.status(500).json({
            message: 'Registration failed',
            error: process.env.NODE_ENV === 'development' ? err.message : undefined
        });
    }
};
export const migrateUsernames = async () => {
    
    const users = await UserModel.find({ 
      $or: [
        { username: { $exists: false } },
        { username: null }
      ]
    });
    
    for (const user of users) {
      
      let baseUsername = user.fullName 
        ? user.fullName.replace(/[^a-zA-Z0-9_]/g, '').substring(0, 15)
        : 'user';
      
      if (!baseUsername) baseUsername = 'user';
      
      let newUsername = `@${baseUsername}`;
      let counter = 1;
      
      
      while (await UserModel.exists({ username: newUsername })) {
        newUsername = `@${baseUsername}${counter}`;
        counter++;
      }
      
      
      await UserModel.updateOne(
        { _id: user._id },
        { $set: { username: newUsername } }
      );
    }
    
    console.log(`Migrated ${users.length} users`);
  };
export const getMe = async (req, res) => {
    try {
        const user = await UserModel.findById(req.userId)
            .select('-passwordHash -__v -verificationCode')
            .populate('subscriptions', 'fullName avatarUrl verified')
            .populate('followers', 'fullName avatarUrl verified');

        if (!user) {
            return res.status(404).json({
                message: 'User not found',
            });
        }

        res.json(user);
    } catch (err) {
        console.error(err);
        res.status(500).json({
            message: 'Failed to get user data',
        });
    }
};

export const subscribe = async (req, res) => {
    try {
        const userId = req.userId;
        const targetUserId = req.params.userId;

        console.log(`[SUBSCRIBE] userId: ${userId} -> targetUserId: ${targetUserId}`);

        if (userId === targetUserId) {
            console.log(`[SUBSCRIBE][ERROR] Пользователь не может подписаться сам на себя: ${userId}`);
            return res.status(400).json({ message: "You can't subscribe to yourself" });
        }

        
        const userBefore = await UserModel.findById(userId);
        const hadNoSubscriptions = !userBefore.subscriptions || userBefore.subscriptions.length === 0;
        const hasFirstSubAward = userBefore.awards && userBefore.awards.some(a => a.title === 'Первая подписка');

        
        await UserModel.findByIdAndUpdate(userId, {
            $addToSet: { subscriptions: targetUserId }
        });

        
        await UserModel.findByIdAndUpdate(targetUserId, {
            $addToSet: { followers: userId }
        });

        
        await UserModel.findByIdAndUpdate(userId, {
            $push: {
                activityLog: {
                    action: 'subscription',
                    details: { targetUserId }
                }
            }
        });

        
        if (hadNoSubscriptions && !hasFirstSubAward) {
            const user = await UserModel.findById(userId);
            user.awards = user.awards || [];
            user.awards.push({
                date: new Date(),
                title: 'Первая подписка',
                description: 'Награда за первую подписку на пользователя',
                issuedBy: null
            });
            user.noth = user.noth || [];
            user.noth.push({
                date: new Date(),
                title: 'Первая подписка',
                description: 'Поздравляем! Вы получили награду за первую подписку.'
            });
            await user.save();
        }

        console.log(`[SUBSCRIBE][SUCCESS] userId: ${userId} подписался на targetUserId: ${targetUserId}`);
        res.json({ message: "Subscription successful" });
    } catch (err) {
        console.error('[SUBSCRIBE][ERROR]', err);
        res.status(500).json({ message: "Subscription failed" });
    }
};

export const unsubscribe = async (req, res) => {
    try {
        const userId = req.userId;
        const targetUserId = req.params.userId;

        console.log(`[UNSUBSCRIBE] userId: ${userId} -> targetUserId: ${targetUserId}`);

        
        await UserModel.findByIdAndUpdate(userId, {
            $pull: { subscriptions: targetUserId }
        });

        
        await UserModel.findByIdAndUpdate(targetUserId, {
            $pull: { followers: userId }
        });

        
        await UserModel.findByIdAndUpdate(userId, {
            $push: {
                activityLog: {
                    action: 'unsubscription',
                    details: { targetUserId }
                }
            }
        });

        console.log(`[UNSUBSCRIBE][SUCCESS] userId: ${userId} отписался от targetUserId: ${targetUserId}`);
        res.json({ message: "Unsubscription successful" });
    } catch (err) {
        console.error('[UNSUBSCRIBE][ERROR]', err);
        res.status(500).json({ message: "Unsubscription failed" });
    }
};

export const getActivity = async (req, res) => {
    try {
        const user = await UserModel.findById(req.userId)
            .select('activityLog -_id')
            .sort({ 'activityLog.timestamp': -1 })
            .limit(20);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(user.activityLog);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Failed to get activity log' });
    }
};

export const getStats = async (req, res) => {
    try {
        const userCount = await UserModel.countDocuments();
        const postCount = await PostModel.countDocuments();
        
        res.json({
            users: userCount,
            posts: postCount,
            updatedAt: new Date()
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Failed to get statistics' });
    }
};


export const requestVerification = async (req, res) => {
    try {
        const { accountType } = req.body;
        
        if (!['verified_user', 'shop'].includes(accountType)) {
            return res.status(400).json({ message: 'Invalid account type' });
        }

        await UserModel.findByIdAndUpdate(req.userId, {
            accountType,
            'verificationData.status': 'pending',
            'verificationData.documents': req.files?.map(file => file.path) || []
        });

        res.json({ 
            success: true,
            message: 'Verification request submitted for review'
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Failed to request verification" });
    }
};


export const approveVerification = async (req, res) => {
    try {
        const { userId, accountType } = req.body;
        
        const user = await UserModel.findByIdAndUpdate(userId, {
            accountType,
            'verificationData.status': 'verified',
            'verificationData.rejectionReason': null
        });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({ 
            success: true,
            message: 'Account verified successfully'
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Failed to verify account" });
    }
};


export const rejectVerification = async (req, res) => {
    try {
        const { userId, reason } = req.body;
        
        const user = await UserModel.findByIdAndUpdate(userId, {
            'verificationData.status': 'rejected',
            'verificationData.rejectionReason': reason
        });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({ 
            success: true,
            message: 'Verification rejected'
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Failed to reject verification" });
    }
};

export const verifyUser = async (req, res) => {
    try {
        const { code } = req.body;
        const user = await UserModel.findById(req.userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        if (user.verificationCode !== code) {
            return res.status(400).json({ message: 'Invalid verification code' });
        }

        await UserModel.findByIdAndUpdate(req.userId, {
            verified: 'verified',
            verificationCode: null
        });

        res.json({ 
            success: true,
            message: 'Account verified successfully'
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Failed to verify account" });
    }
};




export const updateUser = async (req, res) => {
  try {
    
    const userId = req.params.id || req.userId;
    if (req.userId !== userId) {
      return res.status(403).json({ message: 'Недостаточно прав' });
    }

    
    const updateData = {
      fullName: req.body.fullName,
      about: req.body.about || '',
      theme: req.body.theme || 'dark',
      socialMedia: req.body.socialMedia ? JSON.parse(req.body.socialMedia) : {}
    };

    if (typeof req.body.status === 'string' && [...req.body.status].length === 1) {
      updateData.status = req.body.status;
    }

    
    if (req.body.currentPassword && req.body.newPassword) {
      const user = await UserModel.findById(userId);
      if (!user) return res.status(404).json({ message: 'Пользователь не найден' });
      const isValid = await bcrypt.compare(req.body.currentPassword, user.passwordHash);
      if (!isValid) return res.status(400).json({ message: 'Текущий пароль неверный' });
      if (req.body.newPassword.length < 6) return res.status(400).json({ message: 'Новый пароль слишком короткий' });
      user.passwordHash = await bcrypt.hash(req.body.newPassword, 12);
      user.tokenVersion = (user.tokenVersion || 0) + 1;
      await user.save();
      return res.json({ success: true, message: 'Пароль успешно изменён' });
    }

    
    const safeDeleteFile = (filePath) => {
      try {
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
          console.log(`Файл удален: ${filePath}`);
        }
      } catch (err) {
        console.error(`Ошибка при удалении файла ${filePath}:`, err);
      }
    };

    
    if (req.files?.avatar) {
      const avatar = req.files.avatar[0];
      
      const user = await UserModel.findById(userId);
      if (user.avatarUrl) {
        const oldAvatarPath = path.join(__dirname, '..', user.avatarUrl);
        safeDeleteFile(oldAvatarPath);
      }
      updateData.avatarUrl = `/uploads/${avatar.filename}`;
    } else if (req.body.removeAvatar === 'true') {
      
      const user = await UserModel.findById(userId);
      if (user.avatarUrl) {
        const oldAvatarPath = path.join(__dirname, '..', user.avatarUrl);
        safeDeleteFile(oldAvatarPath);
      }
      updateData.avatarUrl = null;
    }

    
    if (req.files?.cover) {
      const cover = req.files.cover[0];
      
      const user = await UserModel.findById(userId);
      if (user.coverUrl) {
        const oldCoverPath = path.join(__dirname, '..', user.coverUrl);
        safeDeleteFile(oldCoverPath);
      }
      updateData.coverUrl = `/uploads/${cover.filename}`;
    } else if (req.body.removeCover === 'true') {
      
      const user = await UserModel.findById(userId);
      if (user.coverUrl) {
        const oldCoverPath = path.join(__dirname, '..', user.coverUrl);
        safeDeleteFile(oldCoverPath);
      }
      updateData.coverUrl = null;
    }

    
    const updatedUser = await UserModel.findByIdAndUpdate(
      userId,
      updateData,
      { 
        new: true,
        runValidators: true 
      }
    ).select('-passwordHash -__v -verificationCode');

    if (!updatedUser) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    
    await UserModel.findByIdAndUpdate(userId, {
      $push: {
        activityLog: {
          action: 'profile_update',
          details: { fields: Object.keys(updateData) },
          timestamp: new Date()
        }
      }
    });

    res.json({
      success: true,
      user: updatedUser
    });

  } catch (err) {
    console.error('Ошибка обновления:', err);
    
    if (req.files?.avatar) {
      const avatarPath = path.join(__dirname, '..', 'uploads', req.files.avatar[0].filename);
      safeDeleteFile(avatarPath);
    }
    if (req.files?.cover) {
      const coverPath = path.join(__dirname, '..', 'uploads', req.files.cover[0].filename);
      safeDeleteFile(coverPath);
    }
    
    let errorMessage = 'Ошибка при обновлении профиля';
    let statusCode = 500;
    if (err.name === 'ValidationError') {
      statusCode = 400;
      errorMessage = Object.values(err.errors).map(val => val.message).join(', ');
    } else if (err.code === 'LIMIT_FILE_SIZE') {
      statusCode = 413;
      errorMessage = 'Размер файла слишком большой (макс. 10MB)';
    }
    res.status(statusCode).json({ 
      success: false,
      message: errorMessage,
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};

export const addToFavorites = async (req, res) => {
  try {
      const { postId } = req.params;
      
      const post = await PostModel.findById(postId);
      if (!post) {
          return res.status(404).json({ message: 'Post not found' });
      }
      
      const user = await UserModel.findByIdAndUpdate(
          req.userId,
          { $addToSet: { favorites: postId } },
          { new: true }
      ).select('favorites');
      
      await UserModel.findByIdAndUpdate(req.userId, {
          $push: {
              activityLog: {
                  action: 'add_to_favorites',
                  details: { postId }
              }
          }
      });
      res.json({
          success: true,
          favorites: user.favorites
      });
  } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Failed to add to favorites" });
  }
};


export const removeFromFavorites = async (req, res) => {
  try {
      const { postId } = req.params;
      
      
      const user = await UserModel.findByIdAndUpdate(
          req.userId,
          { $pull: { favorites: postId } },
          { new: true }
      ).select('favorites');

      
      await UserModel.findByIdAndUpdate(req.userId, {
          $push: {
              activityLog: {
                  action: 'remove_from_favorites',
                  details: { postId }
              }
          }
      });
      await fetchFavorites(); 


      res.json({
          success: true,
          favorites: user.favorites
      });
  } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Failed to remove from favorites" });
  }
};



export const getFavorites = async (req, res) => {
  try {
    const user = await UserModel.findById(req.userId)
      .populate({
        path: 'favorites',
        populate: {
          path: 'user',
          select: 'fullName avatarUrl'
        }
      });
      
    res.json(user.favorites);
  } catch (err) {
    res.status(500).json({ error: "Ошибка сервера" });
  }
};
export const withdrawFunds = async (req, res) => {
  try {
    const { amount } = req.body;
    const userId = req.userId;

    if (amount <= 0) {
      return res.status(400).json({ message: 'Сумма должна быть положительной' });
    }

    const user = await UserModel.findById(userId);
    if (user.balance < amount) {
      return res.status(400).json({ message: 'Недостаточно средств' });
    }

    const transaction = {
      amount: -amount,
      type: 'withdrawal',
      description: req.body.description || 'Списание средств',
      transactionId: generateTransactionId()
    };

    const updatedUser = await UserModel.findByIdAndUpdate(
      userId,
      {
        $inc: { balance: -amount },
        $push: { transactions: transaction }
      },
      { new: true }
    );

    res.json({
      success: true,
      balance: updatedUser.balance,
      transaction
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Ошибка при списании средств" });
  }
};

export const transferFunds = async (req, res) => {
    try {
      const { amount, username, description } = req.body;
      const senderId = req.userId;
  
      
      if (typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ message: 'Некорректная сумма' });
      }
  
      
      const sender = await UserModel.findById(senderId);
      if (!sender) {
        return res.status(404).json({ message: 'Отправитель не найден' });
      }
  
      
      if (sender.username === username) {
        return res.status(400).json({ message: 'Нельзя переводить средства самому себе' });
      }
  
      
      if (sender.balance < amount) {
        return res.status(400).json({ message: 'Недостаточно средств' });
      }
  
      
      const recipient = await UserModel.findOne({ username });
      if (!recipient) {
        return res.status(404).json({ message: 'Получатель не найден' });
      }
  
      
      const transactionId = generateTransactionId();
      const now = new Date();
  
      
      const senderTransaction = { 
        amount: -amount,
        type: 'transfer_out',
        description: description || `Перевод пользователю @${recipient.username}`,
        transactionId,
        relatedUser: recipient._id,
        createdAt: now
      };
  
      const recipientTransaction = {
        amount: amount,
        type: 'transfer_in',
        description: description || `Перевод от пользователя @${sender.username}`,
        transactionId,
        relatedUser: sender._id,
        createdAt: now
      };
  
      
      const session = await mongoose.startSession();
      session.startTransaction();
  
      try {
        
        await UserModel.findByIdAndUpdate(
          senderId,
          {
            $inc: { balance: -amount },
            $push: { transactions: senderTransaction }
          },
          { session, new: true }
        );
  
        
        await UserModel.findByIdAndUpdate(
          recipient._id,
          {
            $inc: { balance: amount },
            $push: { transactions: recipientTransaction }
          },
          { session, new: true }
        );
  
        
        await session.commitTransaction();
        session.endSession();
  
        
        res.json({
          success: true,
          message: 'Перевод выполнен',
          transactionId,
          newBalance: sender.balance - amount
        });
  
      } catch (err) {
        
        await session.abortTransaction();
        session.endSession();
        console.error('Ошибка транзакции:', err);
        throw new Error('Ошибка при выполнении транзакции');
      }
  
    } catch (err) {
      console.error('Ошибка перевода:', {
        error: err.message,
        inputData: req.body
      });
      res.status(500).json({ 
        message: 'Ошибка при переводе средств',
        details: process.env.NODE_ENV === 'development' ? err.message : null
      });
    }
  };

  
const generateTransactionId = () => {
    return 'txn_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  };

export const getTransactions = async (req, res) => {
  try {
    const userId = req.userId;
    const limit = parseInt(req.query.limit) || 20;
    const offset = parseInt(req.query.offset) || 0;

    // Получаем пользователя целиком через lean(), чтобы обойти все правила Mongoose
    const user = await UserModel.findById(userId)
      .select('transactions')
      .lean(); 

    if (!user || !user.transactions) {
      return res.json([]);
    }

    // Сортируем в памяти сервера — это 100% надежно
    const transactions = user.transactions
      .sort((a, b) => {
        const dateA = new Date(a.createdAt || a.date || 0);
        const dateB = new Date(b.createdAt || b.date || 0);
        return dateB - dateA;
      })
      .slice(offset, offset + limit);

    res.json(transactions);
  } catch (err) {
    console.error('Ошибка:', err);
    res.status(500).json({ message: "Ошибка сервера" });
  }
};
export const getBalance = async (req, res) => {
  try {
    const user = await UserModel.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.json({ balance: user.balance });
  } catch (err) {
    console.error('Get balance error:', err);
    res.status(500).json({ message: 'Failed to get balance' });
  }
};


export const migrateTokenVersion = async () => {
  try {
    
    await UserModel.updateMany(
      { tokenVersion: { $exists: true } },
      { $unset: { tokenVersion: "" } }
    );

    
    await UserModel.collection.updateMany(
      {},
      { $set: { tokenVersion: 0 } }
    );
    
    console.log("✅ Миграция tokenVersion завершена");
  } catch (err) {
    console.error("❌ Ошибка миграции:", err);
  }
};

export const getFollowingPosts = async (req, res) => {
  try {
    // ⚠️ Примечание: Убедитесь, что 'mongoose', 'UserModel' и 'PostModel'
    // импортированы и доступны в этом файле.
    const userId = req.userId;
    
    
    const user = await UserModel.findById(userId).select('subscriptions');
    if (!user) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }

    
    if (!Array.isArray(user.subscriptions)) {
      return res.status(400).json({ error: 'Некорректный формат подписок' });
    }

    
    // Проверка на валидность ID (хорошая практика)
    const invalidIds = user.subscriptions.filter(
      id => !mongoose.Types.ObjectId.isValid(id)
    );
    
    if (invalidIds.length > 0) {
      return res.status(400).json({ 
        error: 'Найдены некорректные ID подписок',
        invalidIds 
      });
    }

    
    if (user.subscriptions.length === 0) {
      // Возвращаем только посты самого пользователя, если нет подписок
      // (или пустой массив, в зависимости от вашей логики)
      return res.json([]);
    }

    
    const posts = await PostModel.aggregate([
      { 
        $match: { 
          user: { $in: user.subscriptions } 
        } 
      },
      { $sample: { size: 100 } }, // Выбираем случайные 100 постов
      {
        $lookup: {
          from: 'users',
          localField: 'user',
          foreignField: '_id',
          as: 'user',
          pipeline: [
            { $project: { fullName: 1, avatarUrl: 1 } }
          ]
        }
      },
      { $unwind: '$user' },
      
      // 🛑 ИСПРАВЛЕНИЕ: Добавляем явную проекцию всех необходимых полей поста
      {
        $project: {
          _id: 1, // Обязательно для MongoDB
          title: 1,
          text: 1,
          imageUrl: 1,
          videoUrl: 1, // <--- КЛЮЧЕВОЕ ИСПРАВЛЕНИЕ: Теперь видео будет возвращено
          likes: 1,
          dislikes: 1,
          commentsCount: 1,
          createdAt: 1,
          updatedAt: 1,
          user: 1 // Развернутый объект пользователя
        }
      }
      
    ]);

    res.json(posts);
  } catch (err) {
    console.error('Ошибка получения постов:', err);
    res.status(500).json({ 
      error: 'Ошибка сервера',
      details: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};


export const getUserInfoByUsername = async (req, res) => {
  try {
    const { username } = req.params;
    
    if (!username) {
      return res.status(400).json({ message: 'Username is required' });
    }

    const user = await UserModel.findOne({
      $or: [
        { username: username },
        { username: `@${username}` },
        { fullName: { $regex: new RegExp(`^${username}$`, 'i') } }
      ]
    }).select('-passwordHash -__v -verificationCode -activityLog');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      _id: user._id,
      username: user.username,
      fullName: user.fullName,
      about: user.about,
      avatarUrl: user.avatarUrl,
      coverUrl: user.coverUrl,
      theme: user.theme,
      socialMedia: user.socialMedia,
      accountType: user.accountType,
      verified: user.verified,
      balance: user.balance,
      followersCount: user.followers ? user.followers.length : 0,
      subscriptionsCount: user.subscriptions ? user.subscriptions.length : 0,
      postsCount: user.posts ? user.posts.length : 0,
      createdAt: user.createdAt,
      atomProPlus: user.atomProPlus || null
    });

  } catch (err) {
    console.error('Get user info error:', err);
    res.status(500).json({ 
      message: 'Failed to get user info',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};


export const giveAward = async (req, res) => {
  try {
    const AWARD_SECRET = 'dkI#8duiw8dqywdy'; 
    const { username, userId, title, description, awardSecret } = req.body;
    if (awardSecret !== AWARD_SECRET) {
      return res.status(403).json({ message: 'Неверный секретный пароль' });
    }
    if ((!username && !userId) || !title || !description) {
      return res.status(400).json({ message: 'Необходимы userId или username, а также title и description' });
    }
    let user;
    if (userId) {
      user = await UserModel.findById(userId);
    } else {
      user = await UserModel.findOne({ username });
    }
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    const award = {
      date: new Date(),
      title,
      description,
      issuedBy: null
    };
    user.awards.push(award);
    await user.save();
    res.json({ success: true, message: 'Награда выдана', award });
  } catch (err) {
    console.error('Ошибка выдачи награды:', err);
    res.status(500).json({ message: 'Ошибка выдачи награды' });
  }
};


export const giveAwardToAll = async (req, res) => {
  try {
    
    const admin = await UserModel.findById(req.userId);
    if (!admin || admin.accountType !== 'admin') {
      return res.status(403).json({ message: 'Недостаточно прав' });
    }
    const { title, description } = req.body;
    if (!title || !description) {
      return res.status(400).json({ message: 'Необходимы title и description' });
    }
    const users = await UserModel.find();
    const award = {
      date: new Date(),
      title,
      description,
      issuedBy: admin._id
    };
    for (const user of users) {
      user.awards.push(award);
      await user.save();
    }
    res.json({ success: true, message: 'Награда выдана всем пользователям' });
  } catch (err) {
    console.error('Ошибка массовой выдачи награды:', err);
    res.status(500).json({ message: 'Ошибка массовой выдачи награды' });
  }
};


export const getUserSubscriptions = async (req, res) => {
  try {
    const user = await UserModel.findById(req.params.id).populate('subscriptions', 'username fullName avatarUrl status');
    if (!user) return res.status(404).json({ message: 'Пользователь не найден' });
    res.json({ subscriptions: user.subscriptions });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка получения подписок' });
  }
};


export const getUserFollowers = async (req, res) => {
  try {
    const user = await UserModel.findById(req.params.id).populate('followers', 'username fullName avatarUrl status');
    if (!user) return res.status(404).json({ message: 'Пользователь не найден' });
    res.json({ followers: user.followers });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка получения подписчиков' });
  }
};


export const getNotifications = async (req, res) => {
  try {
    const user = await UserModel.findById(req.userId).select('noth');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user.noth);
  } catch (err) {
    res.status(500).json({ message: 'Ошибка при получении уведомлений', error: err.message });
  }
};




export const notf = async (req, res) => {
  try {
    const { title, description } = req.body;
    const user = await UserModel.findById(req.userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const nothinfo = {
      date: new Date(),
      title,
      description,
    };

    user.noth.push(nothinfo);
    await user.save();

    res.json({ success: true, message: 'Новое уведомление', notification: nothinfo });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка при добавлении уведомления', error: err.message });
  }
};


export const clearNotifications = async (req, res) => {
  try {
    const user = await UserModel.findById(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    user.noth = [];
    await user.save();
    res.json({ success: true, message: 'Уведомления очищены' });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка при очистке уведомлений', error: err.message });
  }
};


export const uc = {
  login,
  register,
  getMe,
  subscribe,
  unsubscribe,
  getActivity,
  getStats,
  requestVerification,
  withdrawFunds,
  transferFunds,
  getTransactions,
  getBalance,
  approveVerification,
  rejectVerification,
  verifyUser,
  updateUser,
  migrateTokenVersion,
  addToFavorites,
  removeFromFavorites,
  getFavorites,
  getFollowingPosts,
  getUserInfoByUsername,
  giveAward,
  notf,
  getNotifications,
  giveAwardToAll,
  getUserSubscriptions,
  getUserFollowers,
  getUserPurchases
};


export const makeAdmin = async (req, res) => {
  try {
    const ADMIN_SECRET = 'dkI#8duiw8dqywdy'; 
    const { userId, adminSecret } = req.body;
    if (adminSecret !== ADMIN_SECRET) {
      return res.status(403).json({ message: 'Неверный секретный пароль' });
    }
    if (!userId) {
      return res.status(400).json({ message: 'Необходим userId' });
    }
    const user = await UserModel.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    user.accountType = 'admin';
    await user.save();
    res.json({ success: true, message: 'Права администратора выданы', user });
  } catch (err) {
    console.error('Ошибка выдачи прав администратора:', err);
    res.status(500).json({ message: 'Ошибка выдачи прав администратора' });
  }
};


export const makeAdminDoubleSecret = async (req, res) => {
  try {
    const ADMIN_SECRET = 'dkI#8duiw8dqywdy'; 
    const urlSecret = req.params.secret;
    const { userId, adminSecret } = req.body;
    
    console.log(`[ADMIN] Попытка выдачи админки: userId=${userId}, urlSecret=${urlSecret}, bodySecret=${adminSecret}, ip=${req.ip}`);
    if (adminSecret !== ADMIN_SECRET || urlSecret !== ADMIN_SECRET) {
      return res.status(403).json({ message: 'Неверный секретный пароль' });
    }
    if (!userId) {
      return res.status(400).json({ message: 'Необходим userId' });
    }
    const user = await UserModel.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    user.accountType = 'admin';
    await user.save();
    res.json({ success: true, message: 'Права администратора выданы', user });
  } catch (err) {
    console.error('Ошибка выдачи прав администратора:', err);
    res.status(500).json({ message: 'Ошибка выдачи прав администратора' });
  }
};
