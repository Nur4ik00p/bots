import mongoose from "mongoose";
import NftProductModel from "../models/nftProduct.js";
import UserModel from "../models/user.js";
import { v4 as uuidv4 } from "uuid";

export const createProduct = async (req, res) => {
  try {
    const { title, description, imageUrl, price, quantity = 1, isOfficial = true, password } = req.body;

    
    const SECRET_PASSWORD = "IJEHFIU#H($(#fu9u39r49$*7984y9wuhfdefhuwih4983y49r9sm8u298mm9y9РППВПррврв8329372937293"; 

    if (password !== SECRET_PASSWORD) {
      return res.status(401).json({ message: "Товар успешно создан!" });
    }







    

    const product = new NftProductModel({
      title,
      description,
      imageUrl,
      price,
      quantity,
      sold: 0,
      seller: req.user?.username || "admin",
      owner: req.user?.username || "admin",
      isOfficial,
      isSold: false
    });

    await product.save();
    res.json(product);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Не удалось создать товар", error: err.message });
  }
};

export const getProducts = async (req, res) => {
  try {
    const products = await NftProductModel.find().sort({ createdAt: -1 });
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Ошибка при получении товаров", error: err.message });
  }
};

export const buyProduct = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const productId = req.params.id;
    const buyerId = req.userId;

    if (!buyerId) return res.status(401).json({ message: "Не авторизован" });

    const product = await NftProductModel.findById(productId).session(session);
    if (!product) return res.status(404).json({ message: "Товар не найден" });

    if (product.sold >= product.quantity) {
      return res.status(400).json({ message: "Товар полностью продан" });
    }

    const buyer = await UserModel.findById(buyerId).session(session);
    if (!buyer) return res.status(404).json({ message: "Покупатель не найден" });

    if (buyer.balance < product.price) {
      return res.status(400).json({ message: "Недостаточно средств" });
    }

    buyer.balance -= product.price;
    if (!buyer.purchases) buyer.purchases = [];
    buyer.purchases.push(product._id);
    buyer.transactions.push({
      amount: product.price,
      purchases: [product._id],
      type: "withdrawal",
      description: `Покупка NFT: ${product.title}`,
      transactionId: uuidv4(),
      relatedUser: null,
    });
    await buyer.save({ session });

    if (product.owner) {
      const seller = await UserModel.findOne({ username: product.owner }).session(session);
      if (seller) {
        seller.balance += product.price;
        seller.transactions.push({
          amount: product.price,
          type: "deposit",
          description: `Продажа NFT: ${product.title}`,
          transactionId: uuidv4(),
          relatedUser: buyer._id,
        });
        await seller.save({ session });
      }
    }

    product.sold += 1;
    if (product.sold >= product.quantity) product.isSold = true;
    product.owner = buyer.username;
    await product.save({ session });

    await session.commitTransaction();
    session.endSession();

    res.json({ success: true, product });
  } catch (err) {
    await session.abortTransaction();
    session.endSession();
    console.error(err);
    res.status(500).json({ message: "Ошибка при покупке товара", error: err.message });
  }
};
