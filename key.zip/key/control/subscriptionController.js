import UserModel from '../models/user.js';
import mongoose from 'mongoose';

// Проверка активности подписки
export const checkSubscription = async (userId) => {
  try {
    const user = await UserModel.findById(userId).select('atomProPlus').lean();
    if (!user || !user.atomProPlus) {
      return false;
    }

    const { isActive, expiresAt } = user.atomProPlus;
    
    // Если подписка не активна, возвращаем false
    if (!isActive) {
      return false;
    }

    // Если срок истек, деактивируем подписку
    if (expiresAt && new Date() > new Date(expiresAt)) {
      await UserModel.findByIdAndUpdate(userId, {
        'atomProPlus.isActive': false
      });
      return false;
    }

    return true;
  } catch (err) {
    console.error('Ошибка проверки подписки:', err);
    return false;
  }
};

// Middleware для проверки подписки
export const requireSubscription = async (req, res, next) => {
  try {
    const hasSubscription = await checkSubscription(req.userId);
    
    if (!hasSubscription) {
      return res.status(403).json({
        success: false,
        message: 'Требуется подписка AtomPro+ для выполнения этого действия',
        requiresSubscription: true
      });
    }

    next();
  } catch (err) {
    console.error('Ошибка проверки подписки:', err);
    res.status(500).json({ message: 'Ошибка проверки подписки' });
  }
};

// Покупка подписки за ATM
export const purchaseSubscriptionATM = async (req, res) => {
  try {
    const { duration } = req.body; // 'week' или 'month'
    const userId = req.userId;

    const user = await UserModel.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    // Цены
    const prices = {
      week: 300,
      month: 0.99 // Для месяца - перенаправление на Telegram
    };

    if (duration === 'month') {
      // Для месяца - перенаправление на Telegram
      return res.json({
        success: true,
        requiresTelegram: true,
        telegramUrl: 'https://t.me/jpegweb',
        message: 'Для покупки месячной подписки свяжитесь с владельцем в Telegram'
      });
    }

    if (duration !== 'week') {
      return res.status(400).json({ message: 'Неверная длительность подписки' });
    }

    const price = prices.week;

    // Проверка баланса
    if (user.balance < price) {
      return res.status(400).json({
        success: false,
        message: `Недостаточно средств. Требуется ${price} ATM`,
        required: price,
        current: user.balance
      });
    }

    // Вычисляем дату окончания
    const now = new Date();
    const expiresAt = new Date(now);
    expiresAt.setDate(expiresAt.getDate() + 7); // +7 дней

    // Обновляем баланс и подписку
    const updatedUser = await UserModel.findByIdAndUpdate(
      userId,
      {
        $inc: { balance: -price },
        $set: {
          'atomProPlus.isActive': true,
          'atomProPlus.expiresAt': expiresAt,
          'atomProPlus.purchasedAt': now,
          'atomProPlus.purchaseType': 'atm'
        },
        $push: {
          transactions: {
            amount: -price,
            type: 'withdrawal',
            description: `Покупка подписки AtomPro+ на неделю`,
            transactionId: `sub_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            createdAt: now
          }
        }
      },
      { new: true }
    ).select('-passwordHash');

    res.json({
      success: true,
      message: 'Подписка AtomPro+ активирована на неделю',
      subscription: {
        isActive: updatedUser.atomProPlus.isActive,
        expiresAt: updatedUser.atomProPlus.expiresAt,
        purchaseType: updatedUser.atomProPlus.purchaseType
      },
      balance: updatedUser.balance
    });
  } catch (err) {
    console.error('Ошибка покупки подписки:', err);
    res.status(500).json({ message: 'Ошибка при покупке подписки' });
  }
};

// Получить информацию о подписке
export const getSubscriptionInfo = async (req, res) => {
  try {
    const userId = req.userId;
    const user = await UserModel.findById(userId).select('atomProPlus balance').lean();
    
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    const isActive = await checkSubscription(userId);
    
    res.json({
      subscription: {
        isActive,
        expiresAt: user.atomProPlus?.expiresAt || null,
        purchasedAt: user.atomProPlus?.purchasedAt || null,
        purchaseType: user.atomProPlus?.purchaseType || null
      },
      balance: user.balance || 0
    });
  } catch (err) {
    console.error('Ошибка получения информации о подписке:', err);
    res.status(500).json({ message: 'Ошибка получения информации о подписке' });
  }
};

// Админ: выдать/убрать подписку
export const adminManageSubscription = async (req, res) => {
  try {
    const admin = await UserModel.findById(req.userId);
    if (!admin || admin.accountType !== 'admin') {
      return res.status(403).json({ message: 'Доступ запрещен' });
    }

    const { userId, action, duration } = req.body; // action: 'grant' или 'revoke', duration в днях

    if (!userId || !action) {
      return res.status(400).json({ message: 'Необходимы userId и action' });
    }

    const targetUser = await UserModel.findById(userId);
    if (!targetUser) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    if (action === 'grant') {
      const days = duration || 30; // По умолчанию 30 дней
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + days);

      await UserModel.findByIdAndUpdate(userId, {
        $set: {
          'atomProPlus.isActive': true,
          'atomProPlus.expiresAt': expiresAt,
          'atomProPlus.purchasedAt': new Date(),
          'atomProPlus.purchaseType': 'admin'
        }
      });

      res.json({
        success: true,
        message: `Подписка AtomPro+ выдана на ${days} дней`,
        expiresAt
      });
    } else if (action === 'revoke') {
      await UserModel.findByIdAndUpdate(userId, {
        $set: {
          'atomProPlus.isActive': false,
          'atomProPlus.expiresAt': null
        }
      });

      res.json({
        success: true,
        message: 'Подписка AtomPro+ отменена'
      });
    } else {
      return res.status(400).json({ message: 'Неверное действие. Используйте "grant" или "revoke"' });
    }
  } catch (err) {
    console.error('Ошибка управления подпиской:', err);
    res.status(500).json({ message: 'Ошибка управления подпиской' });
  }
};

// Админ: получить список пользователей с подпиской
export const adminGetSubscribers = async (req, res) => {
  try {
    const admin = await UserModel.findById(req.userId);
    if (!admin || admin.accountType !== 'admin') {
      return res.status(403).json({ message: 'Доступ запрещен' });
    }

    const users = await UserModel.find({
      'atomProPlus.isActive': true
    })
    .select('username fullName atomProPlus createdAt')
    .lean();

    // Фильтруем тех, у кого подписка не истекла
    const activeSubscribers = users.filter(user => {
      if (!user.atomProPlus || !user.atomProPlus.expiresAt) return false;
      return new Date() < new Date(user.atomProPlus.expiresAt);
    });

    res.json({
      success: true,
      count: activeSubscribers.length,
      subscribers: activeSubscribers.map(user => ({
        _id: user._id,
        username: user.username,
        fullName: user.fullName,
        expiresAt: user.atomProPlus.expiresAt,
        purchasedAt: user.atomProPlus.purchasedAt,
        purchaseType: user.atomProPlus.purchaseType
      }))
    });
  } catch (err) {
    console.error('Ошибка получения подписчиков:', err);
    res.status(500).json({ message: 'Ошибка получения подписчиков' });
  }
};

