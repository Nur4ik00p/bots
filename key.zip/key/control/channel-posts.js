import ChannelModel from '../models/channel.js';
import ChannelPostModel from '../models/channel-post.js';
import UserModel from '../models/user.js';
import { validationResult } from 'express-validator';





export const getChannelPosts = async (req, res) => {
  try {
    const { username } = req.params;
    const { page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    
    const channel = await ChannelModel.findOne({ username, isActive: true });
    if (!channel) {
      return res.status(404).json({
        success: false,
        message: 'Канал не найден'
      });
    }

    
    const posts = await ChannelPostModel.find({
      channel: channel._id,
      isActive: true
    })
      .populate('author', 'fullName username avatarUrl')
      .populate('channel', 'username title')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await ChannelPostModel.countDocuments({
      channel: channel._id,
      isActive: true
    });

    res.json({
      success: true,
      posts,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    console.error('❌ Ошибка получения постов канала:', err);
    res.status(500).json({
      success: false,
      message: 'Не удалось получить посты канала'
    });
  }
};


export const getChannelPost = async (req, res) => {
  try {
    const { postId } = req.params;

    const post = await ChannelPostModel.findOne({
      _id: postId,
      isActive: true
    })
      .populate('author', 'fullName username avatarUrl')
      .populate('channel', 'username title');

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Пост не найден'
      });
    }

    
    post.incrementViews();
    await post.save();

    res.json({
      success: true,
      post
    });
  } catch (err) {
    console.error('❌ Ошибка получения поста канала:', err);
    res.status(500).json({
      success: false,
      message: 'Не удалось получить пост'
    });
  }
};


export const updateChannelPost = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { postId } = req.params;
    const updates = req.body;
    const userId = req.userId;

    const post = await ChannelPostModel.findOne({
      _id: postId,
      isActive: true
    }).populate('channel');

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Пост не найден'
      });
    }

    
    if (post.author.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Вы можете редактировать только свои посты'
      });
    }

    
    if (updates.images && updates.images.length > 3) {
      return res.status(400).json({
        success: false,
        message: 'Максимум 3 изображения в посте'
      });
    }

    
    const updatedPost = await ChannelPostModel.findByIdAndUpdate(
      postId,
      updates,
      { returnDocument: 'after' }
    ).populate('author channel', 'fullName username avatarUrl username title');

    console.log('📝 Пост обновлен в канале:', postId);

    res.json({
      success: true,
      message: 'Пост успешно обновлен',
      post: updatedPost
    });
  } catch (err) {
    console.error('❌ Ошибка обновления поста в канале:', err);
    res.status(500).json({
      success: false,
      message: 'Не удалось обновить пост'
    });
  }
};


export const deleteChannelPost = async (req, res) => {
  try {
    const { postId } = req.params;
    const userId = req.userId;

    const post = await ChannelPostModel.findOne({
      _id: postId,
      isActive: true
    }).populate('channel');

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Пост не найден'
      });
    }

    
    const channel = await ChannelModel.findById(post.channel._id);
    const canDelete = post.author.toString() === userId || 
                     channel.isAdmin(userId);

    if (!canDelete) {
      return res.status(403).json({
        success: false,
        message: 'У вас нет прав на удаление этого поста'
      });
    }

    
    post.isActive = false;
    await post.save();

    
    channel.decrementPostsCount();
    await channel.save();

    console.log('🗑️ Пост удален из канала:', postId);

    res.json({
      success: true,
      message: 'Пост успешно удален'
    });
  } catch (err) {
    console.error('❌ Ошибка удаления поста из канала:', err);
    res.status(500).json({
      success: false,
      message: 'Не удалось удалить пост'
    });
  }
};


export const likeChannelPost = async (req, res) => {
  try {
    const { postId } = req.params;
    const userId = req.userId;

    const post = await ChannelPostModel.findOne({
      _id: postId,
      isActive: true
    });

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Пост не найден'
      });
    }

    
    post.addLike(userId);
    await post.save();

    console.log('👍 Пост лайкнут в канале:', postId);

    res.json({
      success: true,
      message: 'Пост лайкнут',
      likesCount: post.likes.count,
      userLiked: true
    });
  } catch (err) {
    console.error('❌ Ошибка лайка поста в канале:', err);
    res.status(500).json({
      success: false,
      message: 'Не удалось поставить лайк'
    });
  }
};


export const unlikeChannelPost = async (req, res) => {
  try {
    const { postId } = req.params;
    const userId = req.userId;

    const post = await ChannelPostModel.findOne({
      _id: postId,
      isActive: true
    });

    if (!post) {
      return res.status(404).json({
        success: false,
        message: 'Пост не найден'
      });
    }

    
    post.removeLike(userId);
    await post.save();

    console.log('👎 Лайк убран с поста в канале:', postId);

    res.json({
      success: true,
      message: 'Лайк убран',
      likesCount: post.likes.count,
      userLiked: false
    });
  } catch (err) {
    console.error('❌ Ошибка убирания лайка с поста в канале:', err);
    res.status(500).json({
      success: false,
      message: 'Не удалось убрать лайк'
    });
  }
};


export const getUserChannelPosts = async (req, res) => {
  try {
    const userId = req.userId;
    const { page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;

    const posts = await ChannelPostModel.find({
      author: userId,
      isActive: true
    })
      .populate('author', 'fullName username avatarUrl')
      .populate('channel', 'username title')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await ChannelPostModel.countDocuments({
      author: userId,
      isActive: true
    });

    res.json({
      success: true,
      posts,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    console.error('❌ Ошибка получения постов пользователя в каналах:', err);
    res.status(500).json({
      success: false,
      message: 'Не удалось получить посты пользователя'
    });
  }
}; 