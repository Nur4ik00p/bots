import express from 'express';
import mongoose from 'mongoose';
import ChannelModel from '../models/channel.js';
import PostModel from '../models/post.js';
import checkAuth from '../utils/checkAuth.js';

const router = express.Router();


router.post('/', checkAuth, async (req, res) => {
  try {
    const userId = req.userId;  

    const count = await ChannelModel.countDocuments({ owner: userId });
    if (count >= 100) {
      return res.status(400).json({ error: 'Максимум 100 каналов' });
    }

    if (!req.body.nick || !req.body.nick.startsWith('$')) {
      return res.status(400).json({ error: 'Ник должен начинаться с $' });
    }

    const channel = new ChannelModel({
      name: req.body.name,
      nick: req.body.nick.replace(/\s+/g, '').toLowerCase(),
      description: req.body.description || '',
      avatarUrl: req.body.avatarUrl || '',
      owner: userId,
    });

    await channel.save();
    res.status(201).json(channel);
  } catch (err) {
    console.error('Ошибка создания канала:', err);
    res.status(500).json({ error: 'Не удалось создать канал' });
  }
});


router.get('/', async (req, res) => {
  try {
    const channels = await ChannelModel.find()
      .populate('owner', 'fullName avatarUrl');
    res.json(channels);
  } catch (err) {
    res.status(500).json({ error: 'Ошибка получения каналов' });
  }
});




router.get('/my', checkAuth, async (req, res) => {
  try {
    const channels = await ChannelModel.find({ owner: req.userId });
    res.json(channels);
  } catch (err) {
    console.error("Ошибка получения ваших каналов:", err);
    res.status(500).json({ error: 'Ошибка получения ваших каналов' });
  }
});




router.get('/:id', async (req, res) => {
  try {
    const channel = await ChannelModel.findById(req.params.id)
      .populate('owner', 'fullName avatarUrl');
    if (!channel) return res.status(404).json({ error: 'Канал не найден' });
    res.json(channel);
  } catch (err) {
    res.status(500).json({ error: 'Ошибка получения канала' });
  }
});


router.get('/:id/posts', async (req, res) => {
  try {
    const posts = await PostModel.find({ channelId: req.params.id })
      .populate('user', 'fullName avatarUrl profileUrl')
      .populate('channelId', 'name nick');
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: 'Ошибка получения постов канала' });
  }
});


router.patch('/:id', async (req, res) => {
  try {
    const channel = await ChannelModel.findOne({ _id: req.params.id, owner: req.userId });
    if (!channel) return res.status(404).json({ error: 'Канал не найден' });

    if (req.body.name) channel.name = req.body.name;
    if (req.body.description) channel.description = req.body.description;
    if (req.body.avatarUrl) channel.avatarUrl = req.body.avatarUrl;

    await channel.save();
    res.json(channel);
  } catch (err) {
    res.status(500).json({ error: 'Ошибка обновления канала' });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const channel = await ChannelModel.findOneAndDelete({ _id: req.params.id, owner: req.userId });
    if (!channel) return res.status(404).json({ error: 'Канал не найден' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка удаления канала' });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const channel = await ChannelModel.findById(req.params.id);
    if (!channel) {
      return res.status(404).json({ error: 'Канал не найден' });
    }

    
    if (channel.owner.toString() !== req.userId) {
      return res.status(403).json({ error: 'Вы не владелец этого канала' });
    }

    
    await PostModel.deleteMany({ channelId: channel._id });

    
    await ChannelModel.findByIdAndDelete(channel._id);

    res.json({ success: true, message: 'Канал и все его посты удалены' });
  } catch (err) {
    console.error('Ошибка удаления канала:', err);
    res.status(500).json({ error: 'Ошибка удаления канала' });
  }
});


export default router;
