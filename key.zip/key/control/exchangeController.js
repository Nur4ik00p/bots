import ExchangeRequest from "../models/exchangeRequest.js";
import User from "../models/user.js";
import NftProduct from "../models/nftProduct.js";
import transferNft from "./nftTransfer.js";


export async function createRequest(req, res) {
  try {
    const { nftId, toUser, price } = req.body;
    const fromUser = req.user._id; 

    const nft = await NftProduct.findById(nftId);
    if (!nft) throw new Error("NFT не найден");
    if (nft.ownerId.toString() !== fromUser.toString()) {
      throw new Error("Вы не владелец этого NFT");
    }

    const request = await ExchangeRequest.create({
      nftId,
      fromUser,
      toUser,
      price,
    });

    res.json({ success: true, request });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
}


export async function respondRequest(req, res) {
  try {
    const { requestId, action } = req.body;
    const userId = req.user._id;

    const request = await ExchangeRequest.findById(requestId);
    if (!request) throw new Error("Заявка не найдена");

    if (request.toUser.toString() !== userId.toString()) {
      throw new Error("Вы не адресат этой заявки");
    }

    if (request.status !== "pending") {
      throw new Error("Заявка уже обработана");
    }

    if (new Date() > request.expiresAt) {
      request.status = "expired";
      await request.save();
      throw new Error("Срок действия заявки истёк");
    }

    if (action === "accept") {
      await transferNft(request.nftId, request.toUser, request.price);
      request.status = "accepted";
    } else {
      request.status = "rejected";
    }

    await request.save();

    res.json({ success: true, request });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
}

export async function listMyRequests(req, res) {
  try {
    const userId = req.query.userId;
    if (!userId) return res.status(400).json({ success: false, error: "Нет userId" });

    const requests = await ExchangeRequest.find({ toUser: userId, status: "pending" })
      .populate("nftId")
      .populate("fromUser", "username balance")
      .populate("toUser", "username balance");

    res.json({ success: true, requests });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
}
