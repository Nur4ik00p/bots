import mongoose from 'mongoose';
import { post_alert } from '../Tezikov/tezikov.js';
import UserModel from '../models/user.js';
import PostModel from '../models/post.js';


const CommentSchema = new mongoose.Schema({
  postId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Post', 
    required: true 
  },
  user: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  text: { 
    type: String, 
    required: true 
  },
  parentComment: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Comment' 
  },
  replies: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Comment' 
  }],
  createdAt: { 
    type: Date, 
    default: Date.now,
    index: true 
  }
}, { versionKey: false });


const Comment = mongoose.models.Comment || mongoose.model('Comment', CommentSchema);


export const createComment = async (req, res) => {
  try {
    const { text, postId, parentCommentId } = req.body;
    
    console.log('Creating comment:', { text, postId, parentCommentId, userId: req.userId });

    
    if (!text || !postId) {
      return res.status(400).json({
        success: false,
        message: 'Текст комментария и ID поста обязательны'
      });
    }

    
    if (!req.userId) {
      return res.status(401).json({
        success: false,
        message: 'Пользователь не авторизован'
      });
    }

    
    const postExists = await PostModel.exists({ _id: postId });
    if (!postExists) {
      return res.status(404).json({
        success: false,
        message: 'Пост не найден'
      });
    }

    
    const newComment = new Comment({
      postId,
      user: req.userId,
      text,
      parentComment: parentCommentId || null,
      replies: []
    });

    await newComment.save();

    

    
    if (parentCommentId) {
      await Comment.findByIdAndUpdate(parentCommentId, {
        $push: { replies: newComment._id }
      });
    }

    

    
    const currentUser = await UserModel.findById(req.userId);
    if (currentUser) {
      currentUser.noth = currentUser.noth || [];
      currentUser.noth.push({
        date: new Date(),
        title: 'Комментарий создан',
        description: 'Ваш комментарий успешно опубликован.'
      });
      await currentUser.save();
      post_alert('Уведомление о комментарии отправлено', 'комент');
    }

    
    const populatedComment = await Comment.findById(newComment._id)
      .populate('user', 'fullName avatarUrl username');

    
    try {
      const author = await UserModel.findById(req.userId).select('username fullName');
      const authorName = author?.username || author?.fullName || req.userId;
      post_alert(`Создан комментарий ${newComment._id} к посту ${postId} пользователем ${authorName}`, 'create_comment');
    } catch (logErr) {}

    res.status(201).json({
      success: true,
      comment: populatedComment
    });

  } catch (err) {
    console.error('Ошибка при создании комментария:', err);
    res.status(500).json({
      success: false,
      message: 'Ошибка сервера при создании комментария',
      error: err.message
    });
  }
};


export const getAllComments = async (req, res) => {
  try {
    const comments = await Comment.find({})
      .sort({ createdAt: -1 })
      .limit(50)
      .populate('user', 'fullName avatarUrl username')
      .populate('postId', '_id title')
      .populate({
        path: 'replies',
        populate: {
          path: 'user',
          select: 'fullName avatarUrl username'
        }
      });

    res.json({
      success: true,
      comments
    });
  } catch (err) {
    console.error('Ошибка при получении комментариев:', err);
    res.status(500).json({
      success: false,
      message: 'Ошибка сервера при получении комментариев'
    });
  }
};


export const getCommentsForPost = async (req, res) => {
  try {
    const { postId } = req.params;

    

    
    const queryTopLevel = { $or: [ { postId }, { post: postId } ], parentComment: null };
    const queryAll = { $or: [ { postId }, { post: postId } ] };

    const comments = await Comment.find(queryTopLevel)
      .sort({ createdAt: -1 })
      .populate('user', 'fullName avatarUrl username')
      .populate({
        path: 'replies',
        populate: {
          path: 'user',
          select: 'fullName avatarUrl username'
        }
      });

    
    const totalCountSeparate = await Comment.countDocuments(queryAll);

    
    if (!comments.length) {
      
      const post = await PostModel.findById(postId)
        .populate('comments.user', 'fullName avatarUrl username')
        .populate({
          path: 'comments.replies',
          populate: {
            path: 'user',
            select: 'fullName avatarUrl username'
          }
        });

      const embeddedComments = (post?.comments || []).filter(c => !c.parentComment);
      const embeddedCount = (post?.comments || []).length;

      

      
      try {
        for (const c of embeddedComments) {
          await Comment.updateOne(
            { _id: c._id },
            {
              $set: {
                postId,
                user: c.user?._id || c.user,
                text: c.text,
                parentComment: c.parentComment || null,
                createdAt: c.createdAt || new Date()
              },
              $setOnInsert: {
                replies: Array.isArray(c.replies) ? c.replies : []
              }
            },
            { upsert: true }
          );
        }
        
      } catch (mErr) {
        
      }

      
      if (post && typeof post.commentsCount === 'number' && post.commentsCount !== embeddedCount) {
        await PostModel.updateOne({ _id: postId }, { $set: { commentsCount: embeddedCount } });
        
      }

      return res.json({ success: true, postId, count: embeddedCount, comments: embeddedComments });
    }

    

    
    const postForSync = await PostModel.findById(postId).select('commentsCount');
    if (postForSync && typeof postForSync.commentsCount === 'number' && postForSync.commentsCount !== totalCountSeparate) {
      await PostModel.updateOne({ _id: postId }, { $set: { commentsCount: totalCountSeparate } });
      
    }

    return res.json({
      success: true,
      postId,
      count: totalCountSeparate,
      comments
    });

  } catch (err) {
    console.error('Ошибка при получении комментариев поста:', err);
    res.status(500).json({
      success: false,
      message: 'Ошибка сервера при получении комментариев',
      error: err.message
    });
  }
};


export const deleteComment = async (req, res) => {
  try {
    const { commentId } = req.params;
    const userId = req.userId;

    const comment = await Comment.findById(commentId);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: 'Комментарий не найден'
      });
    }

    
    if (comment.user.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Недостаточно прав для удаления'
      });
    }

    
    if (comment.replies.length > 0) {
      await Comment.deleteMany({ _id: { $in: comment.replies } });
    }

    
    await Comment.findByIdAndDelete(commentId);

    
    if (comment.parentComment) {
      await Comment.findByIdAndUpdate(comment.parentComment, {
        $pull: { replies: commentId }
      });
    }

    
    await PostModel.findByIdAndUpdate(comment.postId, {
      $inc: { commentsCount: -1 - comment.replies.length }
    });

    res.json({
      success: true,
      message: 'Комментарий успешно удален'
    });

  } catch (err) {
    console.error('Ошибка при удалении комментария:', err);
    res.status(500).json({
      success: false,
      message: 'Ошибка сервера при удалении комментария',
      error: err.message
    });
  }
};


export const migrateComments = async (req, res) => {
  try {
    console.log('[POST /admin/migrate-comments] start');
    const posts = await PostModel.find({}).select('_id comments commentsCount');
    let updatedTopLevel = 0;
    let updatedReplies = 0;

    for (const post of posts) {
      const postId = post._id;
      const topLevel = post.comments || [];
      for (const c of topLevel) {
        const result = await Comment.updateOne(
          { _id: c._id },
          { $set: { postId } }
        );
        if (result.modifiedCount > 0) updatedTopLevel += 1;
      }
    }

    
    const orphanReplies = await Comment.find({ postId: { $exists: false }, parentComment: { $ne: null } }).select('_id parentComment');
    for (const r of orphanReplies) {
      const parent = await Comment.findById(r.parentComment).select('postId');
      if (parent?.postId) {
        const result = await Comment.updateOne(
          { _id: r._id },
          { $set: { postId: parent.postId } }
        );
        if (result.modifiedCount > 0) updatedReplies += 1;
      }
    }

    console.log('[POST /admin/migrate-comments] done', { updatedTopLevel, updatedReplies });
    return res.json({ success: true, updatedTopLevel, updatedReplies });
  } catch (err) {
    console.error('[POST /admin/migrate-comments] error', err);
    return res.status(500).json({ success: false, message: 'Migration failed', error: err.message });
  }
};


export default {
  createComment,
  getAllComments,
  getCommentsForPost,
  deleteComment,
  migrateComments
};