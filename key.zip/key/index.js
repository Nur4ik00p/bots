import 'dotenv/config';
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import multer from 'multer';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { validationResult } from 'express-validator';
import { registerValidation, loginValidation, PostCreateValidation, musicValidation ,dhubRegisterValidation,dhubLoginValidation} from './validations/auth.js';
import UserModel from './models/user.js';
import PostModel from './models/post.js';
import ChannelModel from './models/channel.js';
import { PS, uc,dhub, checkAdmin, getUserInfoByUsername , CM} from './control/index.js';
import checkAuth from './utils/checkAuth.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import rateLimit from 'express-rate-limit';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { post_alert } from './Tezikov/tezikov.js';
import { giveAward, giveAwardToAll, getUserSubscriptions, getUserFollowers, notf, getNotifications, clearNotifications } from './control/control.js';
import compression from 'compression';
import channelsRouter from './control/channels.js';
import { verifyRecaptcha } from './verifyRecaptcha.js';
import * as StoreController from './control/store.js';
import transferNft from "./control/nftTransfer.js";
import { createRequest, respondRequest, listMyRequests } from "./control/exchangeController.js";
import Nft from "./models/nftProduct.js"; 
import crypto from 'crypto';
import Chat from './models/chat.js';
import Message from './models/message.js';
import Notification from './models/notification.js';
import SendyChat from './models/sendyChat.js';
import * as ChatController from './control/chatController.js';
import * as SendyChatController from './control/sendyChatController.js';
import * as SocketOptimization from './utils/socketOptimization.js';
import { encryptText, generateChatEncryptionKey } from './utils/encryption.js';
import { stream, GetMusic, DeleteMusic, PostTrack, SearchMusic, GetLyrics , toggleLikeTrack, getLikedTracks, getRecommendations , updatePlaylist , getOnePlaylist, removeTrackFromPlaylist, getFlow ,createPlaylist, getAllPlaylists , getMyPlaylists} from './music/stream.js';
import * as SupportController from './control/supportController.js';
import * as SubscriptionController from './control/subscriptionController.js';
import webpush from 'web-push';

webpush.setVapidDetails(
  'mailto:toktybclassic@gmail.com', // твоя почта
process.env.PUSH_PUBLIC_KEY || 'BDniXnUtpUSNDKVj71eAuoZyWSeUEghAhTd1UoG-a2ZgFi39hjuZN9kwg-q2HpELU2E52fwE7MvNzWH_Z0Mhd08',
  process.env.PUSH_PRIVATE_KEY || 'JxMMGfrot-OIjy1pyWcxTDBDdmaj4jnJMhzwyBrxjtM'
);
const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  console.error('MONGODB_URI не задан в .env!');
  process.exit(1);

}
if (!process.env.JWT_SECRET) {
  console.error('JWT_SECRET не задан в .env!');
  process.exit(1);
}


mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log("DB connected successfully");
    const [users, posts, music, groups, channels] = await Promise.all([
      UserModel.countDocuments(),
      PostModel.countDocuments(),
   
      ChannelModel.countDocuments()
    ]);
    console.log(`Статистика: пользователей: ${users}, постов: ${posts}`);
    
    // Batch update вместо загрузки всех юзеров в память
    const result = await UserModel.updateMany(
      { 'awards.title': { $ne: 'Hello world' } },
      { 
        $push: { 
          awards: {
            date: new Date(),
            title: 'Hello world',
            description: 'Награда за начало',
            issuedBy: null
          }
        }
      }
    );
    if (result.modifiedCount > 0) {
      console.log(`Hello world награда выдана ${result.modifiedCount} пользователям`);
    }
  })
  .catch((err) => {
    console.error("DB connection error:", err.message);
    console.log("💡 Make sure your IP is whitelisted in MongoDB Atlas");
   
});



const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: true,
    credentials: true,
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Origin', 'Accept']
  },
  transports: ['websocket'], 
  allowEIO3: false,
  pingInterval: 20000,
  pingTimeout: 45000,
  perMessageDeflate: {
    threshold: 1024 
  },
  maxHttpBufferSize: 1e6 
});
const onlineUsers = new Map();   
const userSockets = new Map();   
const messageBufferByChat = new Map(); 
const MESSAGE_BATCH_INTERVAL_MS = 1000; 
const MESSAGE_BATCH_SIZE = 200; 


setInterval(async () => {
  try {
    for (const [chatId, buffer] of messageBufferByChat.entries()) {
      if (!buffer || buffer.length === 0) continue;
      const toInsert = buffer.splice(0, MESSAGE_BATCH_SIZE);
      
      await Message.insertMany(toInsert, { ordered: false }).catch(err => {
        
        if (process.env.NODE_ENV === 'development') console.error('batch insert error', err);
      });
      
      if (buffer.length === 0) messageBufferByChat.delete(chatId);
    }
  } catch (err) {
    if (process.env.NODE_ENV === 'development') console.error('message batch flush error', err);
  }
}, MESSAGE_BATCH_INTERVAL_MS);


io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    if (!token) return next(new Error('Токен не предоставлен'));

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'isdghfiuhywrg6');
    
    const user = await UserModel.findById(decoded._id).select('_id username fullName avatarUrl accountType').lean();
    if (!user) return next(new Error('Пользователь не найден'));

    socket.userId = user._id.toString();
    socket.user = user; 
    return next();
  } catch (error) {
    if (process.env.NODE_ENV === 'development') console.error('WS auth error', error);
    return next(new Error('Неверный токен'));
  }
});


io.on('connection', (socket) => {
  
  if (process.env.NODE_ENV === 'development') console.log(`WS connected: ${socket.user.username} (${socket.userId})`);

  
  if (!SocketOptimization.checkConnectionLimits(socket.userId)) {
    socket.emit('error', { message: 'Превышен лимит соединений' });
    socket.disconnect(true);
    return;
  }

  SocketOptimization.updateConnectionStats(socket.id, socket.userId);

  
  onlineUsers.set(socket.userId, {
    userId: socket.userId,
    username: socket.user.username,
    fullName: socket.user.fullName,
    avatarUrl: socket.user.avatarUrl,
    socketId: socket.id,
    lastSeen: new Date()
  });
  userSockets.set(socket.userId, socket);


  socket.broadcast.emit('user_online', {
    userId: socket.userId,
    username: socket.user.username,
    fullName: socket.user.fullName,
    avatarUrl: socket.user.avatarUrl
  });

  socket.emit('online_users', Array.from(onlineUsers.values()));

  socket.on('join_chat', async (chatId) => {
    try {
      if (!SocketOptimization.checkMessageLimits(socket.id)) {
        return socket.emit('error', { message: 'Превышен лимит сообщений' });
      }

      const chat = await SendyChat.findOne({
        _id: chatId,
        'participants.userId': socket.userId,
        isActive: true
      }).select('_id participants').lean();

      if (!chat) {
        return socket.emit('error', { message: 'Нет доступа к этому чату' });
      }

      const room = `chat_${chatId}`;
      socket.join(room);

      if (!SocketOptimization.manageRooms(socket, room)) {
        socket.leave(room);
        return socket.emit('error', { message: 'Превышен лимит комнат' });
      }

      socket.emit('joined_chat', { chatId });

      await Message.updateMany(
        { chat: chatId, sender: { $ne: socket.userId }, isRead: false },
        {
          $set: { isRead: true },
          $push: { readBy: { user: socket.userId, readAt: new Date() } }
        }
      ).exec();

    } catch (err) {
      if (process.env.NODE_ENV === 'development') console.error('join_chat error', err);
      socket.emit('error', { message: 'Ошибка присоединения к чату' });
    }
  });

  
  socket.on('send_message', async (data) => {
      console.log('📩 [SERVER] Получено send_message:', data);
    try {
      if (!SocketOptimization.checkMessageLimits(socket.id)) {
        return socket.emit('error', { message: 'Превышен лимит сообщений в минуту' });
      }

      const { chatId, content, replyTo = null, messageType = 'text' } = data || {};
      if (!chatId || !content) return socket.emit('error', { message: 'Неверные данные' });

      
      const chat = await SendyChat.findOne({ _id: chatId, isActive: true })
        .select('_id participants encryptionKeys')
        .lean();

      if (!chat) return socket.emit('error', { message: 'Чат не найден или неактивен' });

      
      const isParticipant = chat.participants.some(p => p.userId.toString() === socket.userId);
      if (!isParticipant) return socket.emit('error', { message: 'Нет доступа к этому чату' });

      SocketOptimization.updateConnectionStats(socket.id, socket.userId, 'message');

      
      let encryptedContent;
      try {
        const { encryptText } = await import('./utils/encryption.js');
        encryptedContent = encryptText(content);
      } catch (e) {
        if (process.env.NODE_ENV === 'development') console.warn('encrypt failed', e);
        encryptedContent = content;
      }

      
      const messageDoc = {
        chat: chatId,
        sender: socket.userId,
        content,
        encryptedContent,
        messageType,
        replyTo,
        encryptionKey: (chat.encryptionKeys && chat.encryptionKeys.length) ? chat.encryptionKeys[chat.encryptionKeys.length - 1] : generateChatEncryptionKey(),
        createdAt: new Date()
      };

      
      if (!messageBufferByChat.has(chatId)) messageBufferByChat.set(chatId, []);
      messageBufferByChat.get(chatId).push(messageDoc);

      
      await SendyChat.findByIdAndUpdate(
        chatId,
        {
          $set: {
            lastMessage: { content, senderId: socket.userId, createdAt: new Date() },
            updatedAt: new Date()
          }
        }
      ).exec();

      
      const senderInfo = await UserModel.findById(socket.userId)
        .select('username fullName avatarUrl accountType')
        .lean();

      const messageForClients = {
        _id: new Date().getTime().toString(), 
        chat: chatId,
        sender: {
          _id: socket.userId,
          username: senderInfo?.username || socket.user.username,
          fullName: senderInfo?.fullName || socket.user.fullName,
          avatarUrl: senderInfo?.avatarUrl || socket.user.avatarUrl || '',
          accountType: senderInfo?.accountType || 'user'
        },
        content,
        messageType,
        replyTo,
        createdAt: new Date()
      };

      
      const room = `chat_${chatId}`;
      io.to(room).emit('new_message', messageForClients);

      
      
      const offlineParticipantIds = chat.participants
        .map(p => p.userId.toString())
        .filter(id => id !== socket.userId && !onlineUsers.has(id));

      if (offlineParticipantIds.length) {
        const notifs = offlineParticipantIds.map(pid => ({
          user: pid,
          type: 'message',
          title: 'Новое сообщение',
          content: `${socket.user.username}: ${content.substring(0, 50)}...`,
          relatedChat: chatId,
          relatedUser: socket.userId,
          createdAt: new Date()
        }));
        
        await Notification.insertMany(notifs).catch(err => {
          if (process.env.NODE_ENV === 'development') console.error('notif insert error', err);
        });
      }

    } catch (err) {
      if (process.env.NODE_ENV === 'development') console.error('send_message error', err);
      socket.emit('error', { message: 'Ошибка отправки сообщения' });
    }
  });

  
  socket.on('mark_read', async (chatId) => {
    try {
      if (!chatId) return socket.emit('error', { message: 'Неверные данные' });

      
      const exists = await SendyChat.exists({ _id: chatId, 'participants.userId': socket.userId, isActive: true });
      if (!exists) return socket.emit('error', { message: 'Нет доступа к этому чату' });

      
      await Message.updateMany(
        { chat: chatId, sender: { $ne: socket.userId }, isRead: false },
        {
          $set: { isRead: true },
          $push: { readBy: { userId: socket.userId, readAt: new Date() } }
        }
      ).exec();

      
      await Notification.deleteMany({ user: socket.userId, relatedChat: chatId, type: 'message' }).exec();

      socket.emit('messages_read', { chatId });
    } catch (err) {
      if (process.env.NODE_ENV === 'development') console.error('mark_read error', err);
      socket.emit('error', { message: 'Ошибка отметки сообщений' });
    }
  });

  
  const typingTimers = new Map(); 
  const TYPING_DEBOUNCE_MS = 1200;

  socket.on('typing_start', ({ chatId }) => {
    if (!chatId) return;
    socket.to(`chat_${chatId}`).emit('user_typing', { userId: socket.userId, username: socket.user.username, isTyping: true });

    
    if (typingTimers.has(chatId)) clearTimeout(typingTimers.get(chatId));
    typingTimers.set(chatId, setTimeout(() => {
      socket.to(`chat_${chatId}`).emit('user_typing', { userId: socket.userId, username: socket.user.username, isTyping: false });
      typingTimers.delete(chatId);
    }, TYPING_DEBOUNCE_MS));
  });

  socket.on('typing_stop', ({ chatId }) => {
    if (!chatId) return;
    if (typingTimers.has(chatId)) {
      clearTimeout(typingTimers.get(chatId));
      typingTimers.delete(chatId);
    }
    socket.to(`chat_${chatId}`).emit('user_typing', { userId: socket.userId, username: socket.user.username, isTyping: false });
  });

  
  socket.on('get_online_users', () => {
    socket.emit('online_users', Array.from(onlineUsers.values()));
  });

  
  socket.on('disconnect', (reason) => {
    if (process.env.NODE_ENV === 'development') console.log(`WS disconnect: ${socket.user.username} (${socket.userId}) reason: ${reason}`);

    SocketOptimization.cleanupConnection(socket.id);
    onlineUsers.delete(socket.userId);
    userSockets.delete(socket.userId);

    socket.broadcast.emit('user_offline', {
      userId: socket.userId,
      username: socket.user.username,
      fullName: socket.user.fullName,
      avatarUrl: socket.user.avatarUrl
    });
  });

  
  socket.on('error', (err) => {
    if (process.env.NODE_ENV === 'development') console.error(`socket error for ${socket.user?.username || socket.id}`, err);
  });
});




const uploadLimiter = rateLimit({
  windowMs: 20 * 1000,
  max: 2,
  keyGenerator: (req) => req.userId,
  message: ''
});

const postLimiter = rateLimit({
  windowMs: 20 * 1000,
  max: 1,
  message: 'Вы можете создавать посты только раз в 20 секунд',
  skipFailedRequests: true,
  keyGenerator: (req) => req.userId
});


const commentLimiter = rateLimit({
  windowMs: 2 * 60 * 1000,
  max: 3,
  keyGenerator: (req) => req.userId || req.ip,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Слишком часто: максимум 3 комментария за 2 минуты. Попробуйте позже.'
  },
  handler: (req, res) => {
    return res.status(429).json({
      success: false,
      message: 'Слишком часто: максимум 3 комментария за 2 минуты. Попробуйте позже.'
    });
  }
});

const storage = multer.diskStorage({
  destination: (_, __, cb) => {
    if (!fs.existsSync('uploads')) {
      fs.mkdirSync('uploads');
    }
    cb(null, 'uploads');
  },
  filename: (_, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, uniqueSuffix + ext);
  },
});

const fileFilter = (req, file, cb) => {
  const filetypes = /jpeg|jpg|png|gif/;
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = filetypes.test(file.mimetype);
  
  if (extname && mimetype) {
    return cb(null, true);
  }
  cb('Error: Images and GIFs only!');
};

const storageTracks = multer.diskStorage({
  destination: (_, __, cb) => {
    // Убедитесь, что папка 'tracks' существует
    if (!fs.existsSync('tracks')) {
      fs.mkdirSync('tracks');
    }
    cb(null, 'tracks'); // Сохраняем в папку tracks
  },
  filename: (_, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, uniqueSuffix + ext);
  },
});

const fileFilterTracks = (req, file, cb) => {
    // Разрешаем только аудиофайлы
    const filetypes = /mp3|wav|ogg|mpeg|audio\/mpeg|audio\/wav|audio\/ogg/;
    const mimetype = filetypes.test(file.mimetype);
    
    if (mimetype) {
        return cb(null, true);
    }
    cb(new Error('Аудиофайлы: Поддерживаются только форматы MP3/WAV/OGG')); // Сообщаем об ошибке
};


// Лимиты для загрузки музыки
const uploadTrack = multer({ 
  storage: storageTracks,
  fileFilter: fileFilterTracks,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB для обычных пользователей
});

const uploadTrackPro = multer({ 
  storage: storageTracks,
  fileFilter: fileFilterTracks,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB для AtomPro+ подписчиков
});

const upload = multer({ 
  storage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 }
});

// Video storage for posts
const storageVideo = multer.diskStorage({
  destination: (_, __, cb) => {
    if (!fs.existsSync('videos')) {
      fs.mkdirSync('videos');
    }
    cb(null, 'videos');
  },
  filename: (_, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, uniqueSuffix + ext);
  },
});

const fileFilterVideo = (req, file, cb) => {
  const filetypes = /mp4|webm|mov|avi|video\/mp4|video\/webm|video\/quicktime/;
  const mimetype = filetypes.test(file.mimetype);
  const extname = /mp4|webm|mov|avi/.test(path.extname(file.originalname).toLowerCase());
  
  if (mimetype || extname) {
    return cb(null, true);
  }
  cb(new Error('Видео: Поддерживаются только форматы MP4/WEBM/MOV'));
};

const uploadVideo = multer({ 
  storage: storageVideo,
  fileFilter: fileFilterVideo,
  limits: { fileSize: 100 * 1024 * 1024 }
});

const uploadPostMedia = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const isVideo = file.mimetype.startsWith('video/');
      const folder = isVideo ? 'videos' : 'uploads';
      if (!fs.existsSync(folder)) {
        fs.mkdirSync(folder);
      }
      cb(null, folder);
    },
    filename: (_, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, uniqueSuffix + ext);
    }
  }),
  fileFilter: (req, file, cb) => {
    const imageTypes = /jpeg|jpg|png|gif/;
    const videoTypes = /mp4|webm|mov/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    
    if (imageTypes.test(ext) || imageTypes.test(file.mimetype)) {
      return cb(null, true);
    }
    if (videoTypes.test(ext) || file.mimetype.startsWith('video/')) {
      return cb(null, true);
    }
    cb(new Error('Неподдерживаемый формат файла'));
  },
  limits: { fileSize: 100 * 1024 * 1024 }
});




// Защита от атак
app.use(compression());

// Лимит размера JSON - защита от DoS
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
// Глобальный rate limiter - ОБЯЗАТЕЛЬНО для слабого сервера
const globalLimiter = rateLimit({
  windowMs: 60, // 1 минута
  max: 100, // 100 запросов в минуту на IP
  message: { error: 'Слишком много запросов. Подождите минуту.' },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.path.startsWith('/stream/') // пропускаем стриминг
});
app.use(globalLimiter);

// Жесткий лимит для API аутентификации (защита от брутфорса)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 минут
  max: 10, // 10 попыток
  message: { error: 'Слишком много попыток входа. Подождите 15 минут.' },
  skipSuccessfulRequests: true
});
app.use('/auth/login', authLimiter);
app.use('/auth/register', authLimiter);

// CORS - ограничь домены в продакшене!
const allowedOrigins = process.env.ALLOWED_ORIGINS 
  ? process.env.ALLOWED_ORIGINS.split(',') 
  : ['http://localhost:3000', 'http://localhost:5173'];

app.use(cors({
  origin: (origin, callback) => {
    // Разрешаем запросы без origin (мобильные приложения, Postman)
    if (!origin || allowedOrigins.includes(origin) || process.env.NODE_ENV !== 'production') {
      callback(null, true);
    } else {
      callback(new Error('CORS blocked'));
    }
  },
  credentials: true,  
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: ["Origin", "X-Requested-With", "Content-Type", "Accept", "Authorization"]
}));






app.use('/uploads', express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), 'uploads')));
app.use('/videos', express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), 'videos')));

app.get('/store/products', StoreController.getProducts);
app.post('/store/products', checkAuth, StoreController.createProduct);
app.post('/store/products/:id/buy', checkAuth, StoreController.buyProduct);

app.post('/admin/give-award', checkAuth, giveAward); 
app.post('/admin/give-award-all', checkAuth, giveAwardToAll); 
app.get("/nft/:id", async (req, res) => {
  try {
    const nft = await Nft.findById(req.params.id).lean();
    if (!nft) {
      return res.status(404).json({ message: "NFT не найден" });
    }
    res.json(nft);
  } catch (err) {
    console.error("Ошибка при получении NFT:", err);
    res.status(500).json({ message: "Ошибка сервера" });
  }
});
app.post(
  "/posts",
  checkAuth,
  uploadPostMedia.single("media"),  
  PS.create
);


app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    console.error('❌ Multer ошибка:', err);

    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        success: false,
        message: 'Файл слишком большой. Максимальный размер: 50MB'
      });
    }

    if (err.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        success: false,
        message: 'Слишком много файлов'
      });
    }

    if (err.code === 'LIMIT_UNEXPECTED_FILE') {
      return res.status(400).json({
        success: false,
        message: 'Неподдерживаемый тип файла'
      });
    }

    return res.status(400).json({
      success: false,
      message: 'Ошибка загрузки файла: ' + err.message
    });
  }

  // ---- FIXED HERE ----
  const msg = err?.message || "";

  if (
    msg.includes('Аudiофайлы:') ||
    msg.includes('Обложка:') ||
    msg.includes('Неподдерживаемый тип файла')
  ) {
    return res.status(400).json({
      success: false,
      message: msg
    });
  }

  next(err);
});

app.post('/auth/save-subscription', checkAuth, async (req, res) => {
  try {
    await UserModel.findByIdAndUpdate(req.userId, {
      pushSubscription: req.body // сохраняем объект подписки в базу
    });
    res.json({ status: 'success' });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка сохранения подписки' });
  }
});
app.get('/playlists/my', checkAuth, getMyPlaylists);
app.post('/auth/save-push', checkAuth, async (req, res) => {
  try {
    // req.body — это тот самый объект с endpoint и keys
    await UserModel.findByIdAndUpdate(req.userId, {
      pushSubscription: req.body 
    });
    console.log('Подписка сохранена для пользователя:', req.userId);
    res.json({ success: true });
  } catch (err) {
    console.error('Ошибка сохранения подписки:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});
// НОВЫЙ (ПРАВИЛЬНЫЙ) МАРШРУТ с проверкой подписки
app.post("/PostTrack", checkAuth, async (req, res, next) => {
  try {
    const hasSubscription = await SubscriptionController.checkSubscription(req.userId);
    
    if (hasSubscription) {
      // Для подписчиков - больший лимит
      return uploadTrackPro.single("track")(req, res, next);
    } else {
      // Для обычных пользователей - лимит 10MB
      return uploadTrack.single("track")(req, res, (err) => {
        if (err && err.code === 'LIMIT_FILE_SIZE') {
          return res.status(400).json({
            success: false,
            message: 'Размер файла превышает 10MB. Для загрузки файлов больше 10MB требуется подписка AtomPro+',
            requiresSubscription: true
          });
        }
        next(err);
      });
    }
  } catch (err) {
    console.error('Ошибка проверки подписки при загрузке:', err);
    return uploadTrack.single("track")(req, res, next);
  }
}, PostTrack);


app.get("/stream/:track", stream);
app.get("/tracks", GetMusic);
app.get("/tracks/search", SearchMusic);
app.get("/tracks/:id/lyrics", GetLyrics);
app.delete("/tracks/:id", checkAuth, DeleteMusic);
app.post('/music/like/:id', checkAuth, toggleLikeTrack);       // Лайк/Дизлайк
app.get('/music/liked', checkAuth, getLikedTracks);            // Любимые треки юзера
app.get('/music/recommendations', checkAuth, getRecommendations); // Умная лента


// Кэши для снижения нагрузки на БД
const postsCache = new Map();
const POSTS_CACHE_TTL = 30000; // 30 секунд

const ratingCache = new Map();
const RATING_CACHE_TTL = 5 * 60 * 1000; // 5 минут для рейтингов

// Хелпер для валидации ObjectId
const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id) && String(new mongoose.Types.ObjectId(id)) === id;

// Быстрый поиск постов
app.get('/posts/search', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.trim().length < 2) {
      return res.json([]);
    }
    
    const searchRegex = new RegExp(q.trim(), 'i');
    const posts = await PostModel.find({
      $or: [
        { title: searchRegex },
        { text: searchRegex }
      ]
    })
    .select('title imageUrl viewsCount commentsCount likes dislikes user createdAt')
    .populate('user', 'fullName username avatarUrl accountType atomProPlus verified')
    .sort({ createdAt: -1 })
    .limit(20)
    .lean();
    
    res.json(posts);
  } catch (err) {
    console.error('Search posts error:', err);
    res.status(500).json({ message: 'Ошибка поиска' });
  }
});

app.get('/posts', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 50); // макс 50
    const skip = (page - 1) * limit;
    const cacheKey = `posts_${page}_${limit}`;

    // Проверяем кэш
    const cached = postsCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < POSTS_CACHE_TTL) {
      return res.json(cached.data);
    }

    // Параллельные запросы с lean() и проекцией
    const [posts, totalPosts] = await Promise.all([
      PostModel.find()
        .select('title imageUrl viewsCount commentsCount likes dislikes user createdAt videoUrl imageUrl mediaType videoDuration')
        .populate('user', 'fullName username avatarUrl accountType atomProPlus verified')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      page === 1 ? PostModel.estimatedDocumentCount() : PostModel.countDocuments()
    ]);

    const response = {
      posts,
      totalPosts,
      currentPage: page,
      totalPages: Math.ceil(totalPosts / limit)
    };

    // Кэшируем первые 3 страницы
    if (page <= 3) {
      postsCache.set(cacheKey, { data: response, timestamp: Date.now() });
    }

    res.json(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: 'Не удалось получить статьи' });
  }
});


app.get('/notifications', checkAuth, getNotifications);

app.post('/notifications', checkAuth, notf); 

app.get('/postNumbers', async (req, res) => {
  try {
    const totalUsers = await UserModel.countDocuments();
    const totalPosts = await PostModel.countDocuments();

    res.json({
      posts: totalPosts,
      users: totalUsers
    });

  } catch (err) {
    console.error('Ошибка в /postNumbers:', err);
    res.status(500).json({
      message: 'Не удалось получить статьи',
      error: err.message,
    });
  }
});


app.get('/playlists', getAllPlaylists); 
app.get('/playlists/:id', getOnePlaylist);
app.post('/playlists', checkAuth, createPlaylist);
app.get("/stream/random", getFlow); // Добавь эту строку (используем твой getFlow или переименуй в getRandomTrack)
const coverStorage = multer.diskStorage({
  destination: (_, __, cb) => {
    if (!fs.existsSync('uploads')) {
      fs.mkdirSync('uploads', { recursive: true });
    }
    cb(null, 'uploads');
  },
  filename: (_, file, cb) => {
    cb(null, `playlist_${Date.now()}_${file.originalname}`);
  },
});
const uploadCover = multer({ storage: coverStorage });
app.post('/upload/playlist-cover', checkAuth, upload.single('image'), (req, res) => {
  try {
    res.json({
      // Теперь ссылка будет просто /uploads/имя_файла.jpg
      url: `/uploads/${req.file.filename}`, 
    });
  } catch (err) {
    res.status(500).json({ message: "Ошибка загрузки" });
  }
});
app.patch('/playlists/:id', checkAuth, updatePlaylist);
app.delete('/playlists/:playlistId/tracks/:trackId', checkAuth, removeTrackFromPlaylist);

app.get('/posts/:id', async (req, res) => {
  try {
    const postId = req.params.id;
    
    if (!isValidObjectId(postId)) {
      return res.status(400).json({ message: 'Неверный ID статьи' });
    }
    
    const post = await PostModel.findOneAndUpdate(
      { _id: postId },
      { $inc: { viewsCount: 1 } },
      { returnDocument: 'after' }
    ).populate('user', 'fullName username avatarUrl accountType atomProPlus verified').lean();
    
    if (!post) {
      return res.status(404).json({ message: 'Статья не найдена' });
    }
    
    res.json(post);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: 'Не удалось получить статью' });
  }
});

app.delete('/posts/:id', checkAuth, async (req, res) => {
  try {
    const postId = req.params.id;
    const post = await PostModel.findById(postId);
    
    if (!post) {
      return res.status(404).json({
        message: 'Статья не найдена',
      });
    }
    
    if (post.user.toString() !== req.userId) {
      return res.status(403).json({
        message: 'Нет доступа',
      });
    }
    
    await PostModel.findByIdAndDelete(postId);
    res.json({
      message: 'Статья удалена',
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      message: 'Не удалось удалить статью',
    });
  }
});

app.patch('/posts/:id', checkAuth, upload.single('image'), async (req, res) => {
  try {
    const postId = req.params.id;
    const post = await PostModel.findById(postId);
    
    if (!post) {
      return res.status(404).json({
        message: 'Статья не найдена',
      });
    }
    
    if (post.user.toString() !== req.userId) {
      return res.status(403).json({
        message: 'Нет доступа',
      });
    }
    
    const updateData = {
      title: req.body.title,
      text: req.body.text,
      tags: req.body.tags ? req.body.tags.split(',').map(tag => tag.trim()) : [],
    };
    
    if (req.file) {
      updateData.imageUrl = `/uploads/${req.file.filename}`;
    }
    
    const updatedPost = await PostModel.findByIdAndUpdate(
      postId,
      updateData,
      { returnDocument: 'after' }
    ).populate('user');
    
    res.json(updatedPost);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      message: 'Не удалось обновить статью',
    });
  }
});

app.get('/posts/user/:userId', async (req, res) => {
  try {
    const posts = await PostModel.find({ user: req.params.userId })
      .populate('user')
      .sort({ createdAt: -1 });
    res.json(posts);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      message: 'Не удалось получить статьи',
    });
  }
});


app.post('/posts/:id/like', checkAuth, PS.likePost);
app.post('/posts/:id/dislike', checkAuth, PS.dislikePost);
app.delete('/posts/:id/like', checkAuth, PS.removeReaction);



app.post("/transfer",checkAuth, transferNft);






app.get("/usersCount", async (req, res) => {
  try {
    const count = await UserModel.countDocuments(); 
    res.json({ count });
  } catch (err) {
    console.error("Ошибка при подсчёте пользователей:", err);
    res.status(500).json({ error: "Ошибка сервера" });
  }
});

app.post('/comment', checkAuth, commentLimiter, CM.createComment);
app.get('/comment/post/:postId', CM.getCommentsForPost);
app.delete('/comment/:commentId', checkAuth, CM.deleteComment);
app.get('/comment', CM.getAllComments);

app.post('/nft/:nftId/pin', checkAuth, async (req, res) => {
  try {
    const userId = req.userId;
    const nftId = req.params.nftId;

    const user = await UserModel.findById(userId);
    if (!user) return res.status(404).json({ message: 'Пользователь не найден' });

    
    if (user.pinnedNfts.some(id => id.toString() === nftId)) {
      return res.json({ message: 'Уже закреплено', pinnedNfts: user.pinnedNfts });
    }

    
    if (user.pinnedNfts.length >= 5) {
      return res.status(400).json({ message: 'Достигнут лимит закрепленных NFT (макс 5)' });
    }

    
    user.purchases = user.purchases.filter(id => id.toString() !== nftId);

    
    user.pinnedNfts.push(nftId);

    await user.save();

    res.json({ message: 'NFT закреплён', pinnedNfts: user.pinnedNfts });
  } catch (err) {
    console.error('Ошибка при закреплении NFT:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

app.post('/test', (req, res) => {
  console.log('BODY RECEIVED:', req.body);
  res.status(200).json({ ok: true, received: req.body });
});

app.delete('/nft/:nftId/pin', checkAuth, async (req, res) => {
  try {
    const userId = req.userId;
    const nftId = req.params.nftId;

    const user = await UserModel.findById(userId);
    if (!user) return res.status(404).json({ message: 'Пользователь не найден' });

    
    user.pinnedNfts = user.pinnedNfts.filter(id => id.toString() !== nftId);

    
    if (!user.purchases.some(id => id.toString() === nftId)) {
      user.purchases.push(nftId);
    }

    await user.save();

    res.json({ message: 'NFT откреплён', pinnedNfts: user.pinnedNfts, purchases: user.purchases });
  } catch (err) {
    console.error('Ошибка при откреплении NFT:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

app.get('/rating/popular-posts', async (req, res) => {
  try {
    // Проверяем кэш - критично для слабого сервера!
    const cached = ratingCache.get('popular-posts');
    if (cached && Date.now() - cached.timestamp < RATING_CACHE_TTL) {
      return res.json(cached.data);
    }
    
    const popularPosts = await PostModel.aggregate([
      {
        $lookup: {
          from: 'users',
          localField: 'user',
          foreignField: '_id',
          as: 'userInfo'
        }
      },
      {
        $unwind: '$userInfo'
      },
      {
        $addFields: {
          likesCount: { $size: { $ifNull: ['$likes.users', []] } },
          dislikesCount: { $size: { $ifNull: ['$dislikes.users', []] } },
          totalEngagement: {
            $add: [
              { $size: { $ifNull: ['$likes.users', []] } },
              { $size: { $ifNull: ['$dislikes.users', []] } },
              { $ifNull: ['$viewsCount', 0] },
              { $ifNull: ['$commentsCount', 0] }
            ]
          }
        }
      },
      {
        $project: {
          _id: 1,
          title: 1,
          imageUrl: 1,
          viewsCount: 1,
          commentsCount: 1,
          likesCount: 1,
          dislikesCount: 1,
          totalEngagement: 1,
          createdAt: 1,
          user: {
            _id: '$userInfo._id',
            username: '$userInfo.username',
            avatarUrl: '$userInfo.avatarUrl',
            fullName: '$userInfo.fullName'
          }
        }
      },
      {
        $sort: { totalEngagement: -1 }
      },
      {
        $limit: 20
      }
    ]);
    
    // Сохраняем в кэш
    ratingCache.set('popular-posts', { data: popularPosts, timestamp: Date.now() });
    res.json(popularPosts);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: 'Не удалось получить популярные посты' });
  }
});

app.get('/rating/active-users', async (req, res) => {
  const cached = ratingCache.get('active-users');
  if (cached && Date.now() - cached.timestamp < RATING_CACHE_TTL) {
    return res.json(cached.data);
  }
  try {
    
    const activeUsers = await UserModel.aggregate([
      {
        $lookup: {
          from: 'posts',
          localField: '_id',
          foreignField: 'user',
          as: 'userPosts'
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: 'followers',
          foreignField: '_id',
          as: 'followersInfo'
        }
      },
      {
        $addFields: {
          postsCount: { $size: { $ifNull: ['$userPosts', []] } },
          followersCount: { $size: { $ifNull: ['$followersInfo', []] } },
          totalActivity: {
            $add: [
              { $size: { $ifNull: ['$userPosts', []] } },
              { $size: { $ifNull: ['$followersInfo', []] } }
            ]
          }
        }
      },
      {
        $project: {
          _id: 1,
          username: 1,
          avatarUrl: 1,
          fullName: 1,
          postsCount: 1,
          followersCount: 1,
          totalActivity: 1,
          createdAt: 1
        }
      },
      {
        $sort: { postsCount: -1, totalActivity: -1 }
      },
      {
        $limit: 20
      }
    ]);
    
    ratingCache.set('active-users', { data: activeUsers, timestamp: Date.now() });
    res.json(activeUsers);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: 'Не удалось получить активных пользователей' });
  }
});

app.get('/rating/popular-users', async (req, res) => {
  const cached = ratingCache.get('popular-users');
  if (cached && Date.now() - cached.timestamp < RATING_CACHE_TTL) {
    return res.json(cached.data);
  }
  try {
    
    const popularUsers = await UserModel.aggregate([
      {
        $lookup: {
          from: 'posts',
          localField: '_id',
          foreignField: 'user',
          as: 'userPosts'
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: 'followers',
          foreignField: '_id',
          as: 'followersInfo'
        }
      },
      {
        $addFields: {
          postsCount: { $size: { $ifNull: ['$userPosts', []] } },
          followersCount: { $size: { $ifNull: ['$followersInfo', []] } },
          totalPopularity: {
            $add: [
              { $multiply: [{ $size: { $ifNull: ['$followersInfo', []] } }, 2] },
              { $size: { $ifNull: ['$userPosts', []] } }
            ]
          }
        }
      },
      {
        $project: {
          _id: 1,
          username: 1,
          avatarUrl: 1,
          fullName: 1,
          postsCount: 1,
          followersCount: 1,
          totalPopularity: 1,
          createdAt: 1
        }
      },
      {
        $sort: { followersCount: -1, totalPopularity: -1 }
      },
      {
        $limit: 20
      }
    ]);
    
    ratingCache.set('popular-users', { data: popularUsers, timestamp: Date.now() });
    res.json(popularUsers);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: 'Не удалось получить популярных пользователей' });
  }
});


app.get('/rating/top-liked-posts', async (req, res) => {
  const cached = ratingCache.get('top-liked');
  if (cached && Date.now() - cached.timestamp < RATING_CACHE_TTL) {
    return res.json(cached.data);
  }
  try {
    const topLikedPosts = await PostModel.aggregate([
      {
        $lookup: {
          from: 'users',
          localField: 'user',
          foreignField: '_id',
          as: 'userInfo'
        }
      },
      {
        $unwind: '$userInfo'
      },
      {
        $addFields: {
          likesCount: { $size: { $ifNull: ['$likes.users', []] } }
        }
      },
      {
        $match: { likesCount: { $gt: 0 } }
      },
      {
        $project: {
          _id: 1,
          title: 1,
          imageUrl: 1,
          likesCount: 1,
          createdAt: 1,
          user: {
            _id: '$userInfo._id',
            username: '$userInfo.username',
            avatarUrl: '$userInfo.avatarUrl',
            fullName: '$userInfo.fullName'
          }
        }
      },
      {
        $sort: { likesCount: -1 }
      },
      {
        $limit: 15
      }
    ]);
    
    ratingCache.set('top-liked', { data: topLikedPosts, timestamp: Date.now() });
    res.json(topLikedPosts);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: 'Не удалось получить посты с наибольшим количеством лайков' });
  }
});
app.use('/channels', channelsRouter);

// Support tickets routes
app.post('/support/tickets', SupportController.createTicket);
app.post('/support/admin/login', SupportController.adminLogin);
app.get('/support/admin/check-block', SupportController.checkBlockStatus);
app.get('/support/admin/tickets', SupportController.checkAdminAuth, SupportController.getTickets);
app.get('/support/admin/stats', SupportController.checkAdminAuth, SupportController.getStats);
app.post('/support/admin/tickets/:id/respond', SupportController.checkAdminAuth, SupportController.respondToTicket);
app.get('/support/my-tickets', checkAuth, SupportController.getUserTickets);




app.post('/chats', checkAuth, SendyChatController.createChat);
app.post('/chats/by-username', checkAuth, SendyChatController.createChat);
app.get('/chats', checkAuth, SendyChatController.getUserChats);
app.get('/chats/:chatId/messages', checkAuth, SendyChatController.getChatMessages);
app.post('/chats/:chatId/messages', checkAuth, SendyChatController.sendMessage);
app.post('/chats/:chatId/read', checkAuth, SendyChatController.markAsRead);
app.delete('/chats/:chatId', checkAuth, SendyChatController.deleteChat);


app.get('/notifications', checkAuth, ChatController.getNotifications);
app.post('/notifications/read', checkAuth, ChatController.markNotificationsAsRead);


app.get('/socket-stats', checkAuth, async (req, res) => {
  try {
    const user = await UserModel.findById(req.userId);
    if (user.accountType !== 'admin') {
      return res.status(403).json({ error: 'Доступ запрещен' });
    }
    
    const stats = SocketOptimization.getConnectionStats();
    res.json(stats);
  } catch (error) {
    console.error('Ошибка получения статистики:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.get('/rating/most-viewed-posts', async (req, res) => {
  try {
    const mostViewedPosts = await PostModel.aggregate([
      {
        $lookup: {
          from: 'users',
          localField: 'user',
          foreignField: '_id',
          as: 'userInfo'
        }
      },
      {
        $unwind: '$userInfo'
      },
      {
        $match: { viewsCount: { $gt: 0 } }
      },
      {
        $project: {
          _id: 1,
          title: 1,
          imageUrl: 1,
          viewsCount: 1,
          createdAt: 1,
          user: {
            _id: '$userInfo._id',
            username: '$userInfo.username',
            avatarUrl: '$userInfo.avatarUrl',
            fullName: '$userInfo.fullName'
          }
        }
      },
      {
        $sort: { viewsCount: -1 }
      },
      {
        $limit: 15
      }
    ]);
    
    res.json(mostViewedPosts);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      message: 'Не удалось получить самые просматриваемые посты',
    });
  }
});

app.get('/rating/user-stats/:userId', async (req, res) => {
  try {
    const userStats = await UserModel.aggregate([
      {
        $match: { _id: new mongoose.Types.ObjectId(req.params.userId) }
      },
      {
        $lookup: {
          from: 'posts',
          localField: '_id',
          foreignField: 'user',
          as: 'userPosts'
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: 'followers',
          foreignField: '_id',
          as: 'followersInfo'
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: 'subscriptions',
          foreignField: '_id',
          as: 'subscriptionsInfo'
        }
      },
      {
        $addFields: {
          postsCount: { $size: { $ifNull: ['$userPosts', []] } },
          followersCount: { $size: { $ifNull: ['$followersInfo', []] } },
          subscriptionsCount: { $size: { $ifNull: ['$subscriptionsInfo', []] } },
          totalLikes: {
            $reduce: {
              input: '$userPosts',
              initialValue: 0,
              in: { $add: ['$$value', { $size: { $ifNull: ['$$this.likes.users', []] } }] }
            }
          },
          totalViews: {
            $reduce: {
              input: '$userPosts',
              initialValue: 0,
              in: { $add: ['$$value', { $ifNull: ['$$this.viewsCount', 0] }] }
            }
          }
        }
      },
      {
        $project: {
          _id: 1,
          username: 1,
          avatarUrl: 1,
          fullName: 1,
          postsCount: 1,
          followersCount: 1,
          subscriptionsCount: 1,
          totalLikes: 1,
          totalViews: 1,
          createdAt: 1
        }
      }
    ]);
    
    if (userStats.length === 0) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    
    res.json(userStats[0]);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      message: 'Не удалось получить статистику пользователя',
    });
  }
});
app.get('/users/info/:username', getUserInfoByUsername);

app.get('/users/:id', async (req, res) => {
  try {
    const user = await UserModel.findById(req.params.id)
      .populate('pinnedNfts')
      .populate('hiddenNfts')
      .populate('purchases')
      .populate('posts');

    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    res.json(user);
  } catch (err) {
    console.error('Ошибка при получении профиля:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});



app.get('/users/:id/subscriptions', getUserSubscriptions);
app.get('/users/:id/followers', getUserFollowers);
app.post('/auth/register', registerValidation, verifyRecaptcha,uc.register);
app.post('/auth/login', uc.login);
app.post('/dhub/login', dhubLoginValidation, dhub.loginhub);
app.post('/dhub/register', dhubRegisterValidation,dhub.registerhub);

app.get('/auth/me', checkAuth, uc.getMe);
app.patch('/auth/me', checkAuth, upload.fields([
  { name: 'avatar', maxCount: 1 },
  { name: 'cover', maxCount: 1 }
]), uc.updateUser);
app.post('/auth/subscribe/:userId', checkAuth, uc.subscribe);
app.delete('/auth/unsubscribe/:userId', checkAuth, uc.unsubscribe);
app.get('/auth/activity', checkAuth, uc.getActivity);
app.get('/auth/stats', checkAuth, uc.getStats);
app.post('/auth/verify/:code', uc.verifyUser);
app.post('/auth/favorites/:postId', checkAuth, uc.addToFavorites);
app.delete('/auth/favorites/:postId', checkAuth, uc.removeFromFavorites);
app.get('/auth/favorites', checkAuth, uc.getFavorites);
app.post('/auth/withdraw', checkAuth, uc.withdrawFunds);
app.post('/auth/transfer', checkAuth, uc.transferFunds);
app.get('/auth/transactions', checkAuth, uc.getTransactions);
app.get('/auth/balance', checkAuth, uc.getBalance);
app.post('/auth/clear-notifications', checkAuth, clearNotifications);
app.get('/posts/following', checkAuth, uc.getFollowingPosts);

// AtomPro+ Subscription Routes
app.post('/subscription/purchase', checkAuth, SubscriptionController.purchaseSubscriptionATM);
app.get('/subscription/info', checkAuth, SubscriptionController.getSubscriptionInfo);
app.post('/admin/subscription/manage', checkAuth, SubscriptionController.adminManageSubscription);
app.get('/admin/subscription/subscribers', checkAuth, SubscriptionController.adminGetSubscribers);





app.get('/:id/purchases', uc.getUserPurchases);

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(200).json({ message: 'Успешно!' });
});

app.use((req, res) => {
  res.status(404).json({ message: 'Страница не найдена' });
});

server.listen(PORT, '0.0.0.0', (err) => {
  if (err) {
    return console.log(err);
  }
  
  console.log(`Сервер запущен на порту ${PORT}`);
})

mongoose.connection.once('open', () => {
  console.log('✅ Подключение к MongoDB установлено');
});
