import mongoose from 'mongoose';

const DHubUserSchema = new mongoose.Schema({
  login: { type: String, required: true, unique: true },          
  passwordHash: { type: String, required: true },                 
  gender: { type: String, enum: ['мужской', 'женский'], required: false },
  email: { type: String, required: false },
  country: { type: String, required: false },
  atomNick: { type: String, required: false },
  programmingLanguage: { type: String, required: true },
  educationInstitution: { type: String, required: false },
  projectsPosition: { type: String, required: false },
  tokensCount: { type: Number, default: 100 },
  premium: { type: Boolean, default: false },
}, { timestamps: true });

export default mongoose.model('DHubUser', DHubUserSchema);
