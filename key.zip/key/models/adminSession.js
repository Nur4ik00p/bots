import mongoose from 'mongoose';

const AdminSessionSchema = new mongoose.Schema({
  ipAddress: { type: String, required: true, unique: true },
  failedAttempts: { type: Number, default: 0 },
  isBlocked: { type: Boolean, default: false },
  blockedUntil: { type: Date, default: null },
  lastAttempt: { type: Date, default: Date.now }
}, { timestamps: true });

AdminSessionSchema.index({ ipAddress: 1 });
AdminSessionSchema.index({ blockedUntil: 1 });

export default mongoose.model('AdminSession', AdminSessionSchema);
