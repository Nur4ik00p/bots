import mongoose from 'mongoose';
// В stream.js
const playlistSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, default: "" },
  cover: { type: String, default: "" },
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  tracks: [{ type: mongoose.Schema.Types.ObjectId, ref: 'music_new' }], // Убедись, что имя модели совпадает (music_new)
  isPublic: { type: Boolean, default: true },
}, { timestamps: true });

export const PlaylistModel = mongoose.model('Playlist', playlistSchema);