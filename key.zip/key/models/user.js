import mongoose from 'mongoose';
import { FORBIDDEN_USERNAMES } from '../utils/forbidden-usernames.js';

const TransactionSchema = new mongoose.Schema({
  amount: {
    type: Number,
    required: true
  },
  type: {
    type: String,
    enum: ['deposit', 'withdrawal', 'transfer_in', 'transfer_out', 'topup', 'topop',"reward","transfer","ref_topup","ref_topop"], // добавил topup из вашего контроллера
    required: true
  },
  description: {
    type: String,
    required: true
  },
  tokenVersion: {
    type: Number,
    default: 0,
    required: false // Сделано необязательным для обхода старых ошибок валидации
  },
  transactionId: {
    type: String,
    required: false, // Временно false, так как в базе есть записи без этого поля
    index: true      // Оставляем индекс, но убираем unique: true до очистки базы
  },
  relatedUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const UserSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
    index: true
  },
  purchases: [{ type: mongoose.Schema.Types.ObjectId, ref: 'NftProduct' }], 

  username: {
    type: String,
    required: [true, 'Username is required'],
    unique: true,
    minlength: [4, 'Username должен быть не меньше 4 символов'],
    maxlength: [20, 'Username должен быть не больше 20 символов'],
    validate: {
      validator: function(v) {
        return /^@[a-zA-Z0-9_]+$/.test(v) && 
              !FORBIDDEN_USERNAMES.includes(v.toLowerCase().replace('@',''));
      },
      message: props => 
          props.value.startsWith('@') 
              ? `Username "${props.value}" is not allowed`
              : 'Username must start with @ and contain only letters, numbers and underscores'
    }
  },
  balance: {
    type: Number,
    default: 0,
    min: 0
  },
  likedTracks: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'music_new' 
  }],
  transactions: [TransactionSchema],
  favorites: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Post',
  }],
  
  passwordHash: {
    type: String,
    required: true,
  },
  avatarUrl: String,
  coverUrl: String,
  about: {
    type: String,
    default: '',
    maxlength: 500
  },

  accountType: {
    type: String,
    enum: ['user', 'verified_user', 'shop', 'admin'],
    default: 'user'
  },
  
  subscriptions: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }],
  followers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }],
  posts: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Post',
  }],
  pinnedNfts: [{ type: mongoose.Schema.Types.ObjectId, ref: 'NftProduct' }],
  hiddenNfts: [{ type: mongoose.Schema.Types.ObjectId, ref: 'NftProduct' }],

  awards: [{
    date: { type: Date, default: Date.now },
    title: { type: String, required: true },
    description: { type: String, required: true },
    issuedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, 
  }],

  noth: [
    {
      date: { type: Date, default: Date.now },
      title: String,
      description: String
    }
  ],
  pushSubscription: {
    type: Object,
    default: null
  },

  // AtomPro+ Subscription
  atomProPlus: {
    isActive: { type: Boolean, default: false },
    expiresAt: { type: Date, default: null },
    purchasedAt: { type: Date, default: null },
    purchaseType: { type: String, enum: ['atm', 'telegram'], default: null }
  }
}, {
  timestamps: true,
  toJSON: {
    virtuals: true,
    transform: function(doc, ret) {
      delete ret.passwordHash;
      delete ret.__v;
      return ret;
    }
  }
});

UserSchema.virtual('profileUrl').get(function() {
  return `/users/${this._id}`;
});

export default mongoose.model('User', UserSchema);
