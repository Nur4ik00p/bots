import mongoose from 'mongoose';

const channelPostSchema = new mongoose.Schema({
  
  channel: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Channel',
    required: true
  },
  
  
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  
  
  text: {
    type: String,
    required: true,
    trim: true,
    maxlength: 5000
  },
  
  
  images: [{
    type: String,
    validate: {
      validator: function(v) {
        return this.images.length <= 3;
      },
      message: 'Максимум 3 изображения в посте'
    }
  }],
  
  
  secure: {
    type: Boolean,
    default: false
  },
  
  
  likes: {
    count: {
      type: Number,
      default: 0
    },
    users: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }]
  },
  
  
  viewsCount: {
    type: Number,
    default: 0
  },
  
  
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});


channelPostSchema.index({ channel: 1, createdAt: -1 });
channelPostSchema.index({ author: 1 });
channelPostSchema.index({ isActive: 1 });


channelPostSchema.methods.addLike = function(userId) {
  if (!this.likes.users.includes(userId)) {
    this.likes.users.push(userId);
    this.likes.count = this.likes.users.length;
  }
  return this;
};

channelPostSchema.methods.removeLike = function(userId) {
  this.likes.users = this.likes.users.filter(id => id.toString() !== userId.toString());
  this.likes.count = this.likes.users.length;
  return this;
};

channelPostSchema.methods.hasLiked = function(userId) {
  return this.likes.users.some(id => id.toString() === userId.toString());
};


channelPostSchema.methods.incrementViews = function() {
  this.viewsCount += 1;
  return this;
};

export default mongoose.model('ChannelPost', channelPostSchema); 