import mongoose from "mongoose";

const NftProductSchema = new mongoose.Schema({
  title: String,
  description: String,
  imageUrl: String,
  price: Number,
  seller: String,
  owner: String,
  isOfficial: Boolean,
  isSold: { type: Boolean, default: false },
  quantity: { type: Number, default: 1 }, 
  sold: { type: Number, default: 0 },     
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model("NftProduct", NftProductSchema);
