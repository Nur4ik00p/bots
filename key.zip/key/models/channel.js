import mongoose from 'mongoose';

const ChannelSchema = new mongoose.Schema({
  name: { type: String, required: true,maxlength: 100 },
  nick: { type: String, required: true, unique: true }, 
  description: { type: String, default: '',maxlength: 200 },
  avatarUrl: { type: String, default: '' },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
}, { timestamps: true });

export default mongoose.model('Channel', ChannelSchema);
