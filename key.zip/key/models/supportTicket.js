import mongoose from 'mongoose';

const SupportTicketSchema = new mongoose.Schema({
  name: { type: String, required: true },
  nickname: { type: String, required: true },
  type: { 
    type: String, 
    required: true,
    enum: ['Баг', 'Предложение', 'Вопрос', 'Сотрудничество', 'Реклама', 'Оплата', 
           'Регистрация', 'Авторизация', 'UI/UX', 'Скорость работы', 'Мобильная версия',
           'API', 'Документация', 'Поддержка', 'Безопасность', 'Контент', 'Функционал',
           'Обновления', 'Ошибки перевода', 'Другое']
  },
  message: { type: String, required: true },
  status: {
    type: String,
    enum: ['pending', 'in_progress', 'resolved', 'rejected'],
    default: 'pending'
  },
  response: { type: String, default: null },
  respondedAt: { type: Date, default: null },
  respondedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  ipAddress: { type: String },
  userAgent: { type: String }
}, { timestamps: true });

SupportTicketSchema.index({ nickname: 1 });
SupportTicketSchema.index({ status: 1 });
SupportTicketSchema.index({ createdAt: -1 });

export default mongoose.model('SupportTicket', SupportTicketSchema);
