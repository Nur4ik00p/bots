// utils/checkAuth.js (ИСПРАВЛЕННЫЙ КОД)

import jwt from 'jsonwebtoken';
import UserModel from '../models/user.js';

export default async (req, res, next) => {
    try {
        const token = (req.headers.authorization || '').replace(/Bearer\s?/, '');
        if (!token) return res.status(403).json({ message: 'Токен отсутствует' });

        // УДАЛЕН БЛОК ПРОВЕРКИ СТАРЫМ КЛЮЧОМ

        // ПРОВЕРКА АКТУАЛЬНЫМ КЛЮЧОМ
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'isdghfiuhywrg6');
        const user = await UserModel.findById(decoded._id);
        
        if (!user || decoded.tokenVersion !== user.tokenVersion) {
            // Логика для токенов с неверной версией или удаленных пользователей
            return res.status(401).json({ message: 'Недействительный токен' });
        }

        req.userId = decoded._id;
        // ВСЕ ОК, ПРОДОЛЖАЕМ
        next();
    } catch (err) {
        // Если jwt.verify выбросит ошибку (неверный/просроченный токен), попадаем сюда
        res.status(403).json({ message: 'Ошибка аутентификации' });
    }
};