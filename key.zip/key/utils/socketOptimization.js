


const activeConnections = new Map();
const connectionStats = new Map();


const OPTIMIZATION_CONFIG = {
  maxConnectionsPerUser: 3,
  heartbeatInterval: 30000, 
  connectionTimeout: 60000, 
  maxMessagesPerMinute: 60,
  maxRoomsPerConnection: 10
};


export const cleanupInactiveConnections = () => {
  const now = Date.now();
  
  for (const [userId, connections] of activeConnections.entries()) {
    const filteredConnections = connections.filter(conn => {
      const lastActivity = connectionStats.get(conn.socketId)?.lastActivity || 0;
      return (now - lastActivity) < OPTIMIZATION_CONFIG.connectionTimeout;
    });
    
    if (filteredConnections.length === 0) {
      activeConnections.delete(userId);
    } else {
      activeConnections.set(userId, filteredConnections);
    }
  }
};


export const checkConnectionLimits = (userId) => {
  const userConnections = activeConnections.get(userId) || [];
  
  if (userConnections.length >= OPTIMIZATION_CONFIG.maxConnectionsPerUser) {
    
    const oldestConnection = userConnections.sort((a, b) => 
      connectionStats.get(a.socketId)?.connectedAt - connectionStats.get(b.socketId)?.connectedAt
    )[0];
    
    oldestConnection.disconnect();
    return false;
  }
  
  return true;
};


export const updateConnectionStats = (socketId, userId, event = 'activity') => {
  const now = Date.now();
  const stats = connectionStats.get(socketId) || {
    userId,
    connectedAt: now,
    lastActivity: now,
    messageCount: 0,
    rooms: new Set()
  };
  
  stats.lastActivity = now;
  
  if (event === 'message') {
    stats.messageCount++;
  }
  
  connectionStats.set(socketId, stats);
  
  
  if (!activeConnections.has(userId)) {
    activeConnections.set(userId, []);
  }
  
  const userConnections = activeConnections.get(userId);
  if (!userConnections.find(conn => conn.socketId === socketId)) {
    userConnections.push({ socketId, socket: null }); 
  }
};


export const checkMessageLimits = (socketId) => {
  const stats = connectionStats.get(socketId);
  if (!stats) return false;
  
  const now = Date.now();
  const oneMinuteAgo = now - 60000;
  
  
  if (stats.lastActivity < oneMinuteAgo) {
    stats.messageCount = 0;
    connectionStats.set(socketId, stats);
  }
  
  return stats.messageCount < OPTIMIZATION_CONFIG.maxMessagesPerMinute;
};


export const manageRooms = (socket, roomName) => {
  const socketId = socket.id;
  const stats = connectionStats.get(socketId);
  
  if (!stats) return false;
  
  if (stats.rooms.size >= OPTIMIZATION_CONFIG.maxRoomsPerConnection) {
    
    const oldestRoom = Array.from(stats.rooms)[0];
    socket.leave(oldestRoom);
    stats.rooms.delete(oldestRoom);
  }
  
  socket.join(roomName);
  stats.rooms.add(roomName);
  connectionStats.set(socketId, stats);
  
  return true;
};


export const cleanupConnection = (socketId) => {
  const stats = connectionStats.get(socketId);
  if (!stats) return;
  
  
  const userConnections = activeConnections.get(stats.userId);
  if (userConnections) {
    const filtered = userConnections.filter(conn => conn.socketId !== socketId);
    if (filtered.length === 0) {
      activeConnections.delete(stats.userId);
    } else {
      activeConnections.set(stats.userId, filtered);
    }
  }
  
  
  connectionStats.delete(socketId);
};


export const getConnectionStats = () => {
  return {
    activeUsers: activeConnections.size,
    totalConnections: connectionStats.size,
    averageConnectionsPerUser: activeConnections.size > 0 
      ? Array.from(activeConnections.values()).reduce((sum, conns) => sum + conns.length, 0) / activeConnections.size 
      : 0
  };
};


setInterval(cleanupInactiveConnections, OPTIMIZATION_CONFIG.heartbeatInterval);

export default {
  cleanupInactiveConnections,
  checkConnectionLimits,
  updateConnectionStats,
  checkMessageLimits,
  manageRooms,
  cleanupConnection,
  getConnectionStats
};

