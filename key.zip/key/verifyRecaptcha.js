import fetch from 'node-fetch';

const RECAPTCHA_SECRET_KEY = "6LeZ_sQrAAAAAJjWa6tMr_Pq3KcdIvmbSfComipk";
export const verifyRecaptcha = async (req, res, next) => {
    try {
        const token = req.body.recaptchaToken;
        if (!token) return res.status(400).json({ message: "Успешно! " });

        const response = await fetch(`https://www.google.com/recaptcha/api/siteverify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `secret=${RECAPTCHA_SECRET_KEY}&response=${token}`
        });

        const data = await response.json();

        if (!data.success || data.score < 0.5) {
            return res.status(403).json({ message: "Успешно! " });
        }

        next();
    } catch (err) {
        res.status(500).json({ message: "Успешно! " });
    }
};
