import fs, { existsSync, statSync, createReadStream } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import mongoose, { Schema, model } from "mongoose";
import e from 'express';
import Post from "../models/post.js";
import UserModel from "../models/user.js";
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Кэш метаданных файлов для быстрого стриминга
const fileMetaCache = new Map();
const META_CACHE_TTL = 60000; // 1 минута
const trackSchema = new mongoose.Schema({
  title: { type: String, required: true, index: 'text' },
  trackname: { type: String, required: true },
  cover: { type: String, required: true },
likesCount: { type: Number, default: 0, index: true }, // index нужен для быстрой сортировки
  authorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  authorName: { type: String, required: true, index: 'text' },

  album: { type: String, default: "" },
  description: { type: String, default: "" },
  genre: { type: String, required: true },
  label: { type: String, default: "" },
  disc: { type: String, default: "" },
  playlist: { type: String, default: "" },
  trackAuthor: { type: String, default: "" },
  
  // Субтитры/текст песни
  lyrics: { type: String, default: "" },
  // Синхронизированные субтитры в формате LRC
  syncedLyrics: [{
    time: { type: Number }, // время в секундах
    text: { type: String }
  }],
  duration: { type: Number, default: 0 }, // длительность в секундах
}, { timestamps: true });

// Индекс для быстрого поиска
trackSchema.index({ title: 'text', authorName: 'text', album: 'text' });

const Track = model("music_new", trackSchema);

const playlistSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, default: "" },
  cover: { type: String, default: "" },
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  tracks: [{ type: mongoose.Schema.Types.ObjectId, ref: 'music_new' }], // Ссылка на твою модель треков
  isPublic: { type: Boolean, default: true },
}, { timestamps: true });

// 2. Создаем саму модель (именно её не хватало!)
export const PlaylistModel = mongoose.model('Playlist', playlistSchema);

async function seedTracks() {
  const count = await Track.countDocuments();
  if (count === 0) {
    await Track.insertMany([
      {
        title: "Vlone Durov",
        trackname: "1.mp3",
        cover: "https://hrf.org/wp-content/uploads/2025/05/Latest-Thumbnail-French-Courts-Block-Telegram-founder-Pavel-Durov-from-Attending-Oslo-Freedom-Forum-V1.png",
      },
      {
        title: "United by music",
        trackname: "323.mp3",
        cover: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUSExISFhUVGBUXFxcXFRUYFRgXFxUXFxUWGBUYHSggGBolHRYXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGi0fHx8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKy0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH...",
      }
    ]);
    console.log("Base tracks seeded.");
  }
}
export const stream = (req, res) => {
    const trackName = req.params.track;
    const trackPath = join(__dirname, '..', 'tracks', trackName);

    // Проверяем кэш метаданных
    let fileMeta = fileMetaCache.get(trackName);
    if (!fileMeta || Date.now() - fileMeta.timestamp > META_CACHE_TTL) {
        if (!existsSync(trackPath)) {
            return res.status(404).json({ error: 'Track not found' });
        }
        const stat = statSync(trackPath);
        fileMeta = { size: stat.size, timestamp: Date.now() };
        fileMetaCache.set(trackName, fileMeta);
    }

    const fileSize = fileMeta.size;
    const range = req.headers.range;

    // Оптимальный размер чанка (512KB для быстрого старта)
    const CHUNK_SIZE = 512 * 1024;

    if (range) {
        const [startStr, endStr] = range.replace(/bytes=/, "").split("-");
        const start = parseInt(startStr, 10);
        // Ограничиваем размер чанка для быстрой доставки
        const end = endStr ? Math.min(parseInt(endStr, 10), start + CHUNK_SIZE - 1) : Math.min(start + CHUNK_SIZE - 1, fileSize - 1);
        const chunkSize = end - start + 1;

        res.writeHead(206, {
            "Content-Range": `bytes ${start}-${end}/${fileSize}`,
            "Accept-Ranges": "bytes",
            "Content-Length": chunkSize,
            "Content-Type": "audio/mpeg",
            "Cache-Control": "public, max-age=86400", 
            "X-Content-Duration": "", 
        });

        const stream = createReadStream(trackPath, { start, end, highWaterMark: 64 * 1024 });
        stream.pipe(res);
        
        stream.on('error', (err) => {
            console.error('Stream error:', err);
            if (!res.headersSent) res.status(500).end();
        });
    } else {
        res.writeHead(200, {
            'Content-Length': fileSize,
            'Content-Type': 'audio/mpeg',
            'Accept-Ranges': 'bytes',
            'Cache-Control': 'public, max-age=86400',
        });
        
        const stream = createReadStream(trackPath, { highWaterMark: 64 * 1024 });
        stream.pipe(res);
        
        stream.on('error', (err) => {
            console.error('Stream error:', err);
            if (!res.headersSent) res.status(500).end();
        });
    }
};

export const toggleLikeTrack = async (req, res) => {
  try {
    const userId = req.userId; // Получаем из middleware checkAuth
    const trackId = req.params.id;

    // Проверяем, лайкнул ли уже пользователь этот трек
    const user = await UserModel.findById(userId);
    const isLiked = user.likedTracks.includes(trackId);

    if (isLiked) {
      await UserModel.findByIdAndUpdate(userId, {
        $pull: { likedTracks: trackId }
      });
      await Track.findByIdAndUpdate(trackId, {
        $inc: { likesCount: -1 }
      });
      return res.json({ success: true, message: 'Лайк убран', status: false });
    } else {
      await UserModel.findByIdAndUpdate(userId, {
        $addToSet: { likedTracks: trackId } 
      });
      await Track.findByIdAndUpdate(trackId, {
        $inc: { likesCount: 1 }
      });
      return res.json({ success: true, message: 'Трек лайкнут', status: true });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Ошибка при изменении лайка' });
  }
};


export const getLikedTracks = async (req, res) => {
  try {
    const user = await UserModel.findById(req.userId)
      .populate('likedTracks') // Заполняем данными треков
      .select('likedTracks');

    if (!user) return res.status(404).json({ message: 'Пользователь не найден' });

    res.json(user.likedTracks);
  } catch (err) {
    res.status(500).json({ message: 'Ошибка получения любимых треков' });
  }
};

export const getRecommendations = async (req, res) => {
  try {
    const userId = req.userId;
    
    // 1. Получаем предпочтения пользователя
    const user = await UserModel.findById(userId).populate('likedTracks');
    
    // Если пользователь новичок и лайков нет -> возвращаем самые популярные/новые
    if (!user || user.likedTracks.length === 0) {
      const popularTracks = await Track.find()
        .sort({ likesCount: -1, createdAt: -1 }) // Сначала популярные, потом новые
        .limit(10)
        .lean();
      return res.json({ type: 'popular', tracks: popularTracks });
    }

    // 2. Анализ вкусов
    const likedTrackIds = user.likedTracks.map(t => t._id);
    const favoriteGenres = [...new Set(user.likedTracks.map(t => t.genre))]; // Уникальные жанры
    const favoriteAuthors = [...new Set(user.likedTracks.map(t => t.authorId))]; // Уникальные авторы

    // 3. Поиск похожих треков (Aggregation Pipeline для эффективности)
    const recommendations = await Track.aggregate([
      {
        $match: {
          _id: { $nin: likedTrackIds }, // Исключаем уже лайкнутые
          $or: [
            { genre: { $in: favoriteGenres } },    // Совпадает жанр
            { authorId: { $in: favoriteAuthors } } // Совпадает автор
          ]
        }
      },
      {
        $addFields: {
          // Добавляем вес: если совпадает автор - 2 очка, если жанр - 1 очко (примерно)
          score: {
            $add: [
              { $cond: [{ $in: ["$authorId", favoriteAuthors] }, 2, 0] },
              { $cond: [{ $in: ["$genre", favoriteGenres] }, 1, 0] },
              // Можно добавить влияние популярности
              { $divide: ["$likesCount", 100] } 
            ]
          }
        }
      },
      { $sort: { score: -1, createdAt: -1 } }, // Сортируем по релевантности
      { $limit: 15 } // Берем топ-15
    ]);

    // 4. Если рекомендаций мало (специфичный вкус), добавляем популярные
    if (recommendations.length < 5) {
      const popular = await Track.find({
        _id: { $nin: [...likedTrackIds, ...recommendations.map(r => r._id)] }
      })
      .sort({ likesCount: -1 })
      .limit(5 - recommendations.length)
      .lean();
      
      recommendations.push(...popular);
    }

    res.json({ 
      type: 'personalized', 
      basedOnGenres: favoriteGenres,
      tracks: recommendations 
    });

  } catch (err) {
    console.error("Ошибка рекомендаций:", err);
    res.status(500).json({ message: "Не удалось получить рекомендации" });
  }
};

export const GetMusic = async (req, res) => {
  try {
    const tracks = await Track.find()
      .select('title trackname cover authorId authorName album genre duration lyrics')
      .sort({ createdAt: -1 })
      .lean();
    res.json(tracks);
  } catch (err) {
    res.status(500).json({ message: 'Ошибка загрузки треков' });
  }
};

// Поиск музыки
export const SearchMusic = async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.trim().length < 2) {
      return res.json([]);
    }
    
    const searchRegex = new RegExp(q.trim(), 'i');
    const tracks = await Track.find({
      $or: [
        { title: searchRegex },
        { authorName: searchRegex },
        { album: searchRegex }
      ]
    })
    .select('title trackname cover authorId authorName album genre duration')
    .limit(20)
    .lean();
    
    res.json(tracks);
  } catch (err) {
    console.error('Search music error:', err);
    res.status(500).json({ message: 'Ошибка поиска' });
  }
};

// Получить субтитры трека
export const GetLyrics = async (req, res) => {
  try {
    const { id } = req.params;
    const track = await Track.findById(id).select('lyrics syncedLyrics title authorName').lean();
    
    if (!track) {
      return res.status(404).json({ message: 'Трек не найден' });
    }
    
    res.json({
      title: track.title,
      authorName: track.authorName,
      lyrics: track.lyrics || '',
      syncedLyrics: track.syncedLyrics || []
    });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка получения субтитров' });
  }
};
export const DeleteMusic = async  (req, res) => {
  try {
    const trackId = req.params.id;
    const deletedTrack = await Track.findByIdAndDelete(trackId);

    if (!deletedTrack) {
      return res.status(404).json({ message: "Трек не найден" });
    }

    res.json({ message: "Трек успешно удален", track: deletedTrack });
  } catch (err) {
    res.status(500).json({ message: "Ошибка при удалении трека", error: err });
  }
};
export const PostTrack = async (req, res) => {
    try {
        // 1. Получение ID автора из checkAuth
        const authorId = req.userId; // ID пользователя, установленный в checkAuth
        
        if (!authorId) {
            // Фактически это должен отлавливать checkAuth, но для надежности оставляем
            return res.status(401).json({ 
                message: "Нет доступа. Требуется авторизация." 
            });
        }
        
        // 2. Получение данных автора для authorName (требуется схемой)
        const user = await UserModel.findById(authorId).select('fullName username').lean();

        if (!user) {
            return res.status(404).json({ message: "Ошибка: Автор не найден." });
        }

        // Выберите, какое имя использовать, в зависимости от вашей схемы
        const authorName = user.fullName || user.username || "Неизвестный автор"; 
        
        // 3. Деструктуризация данных из тела запроса
        const { 
            title, 
            genre, 
            cover, 
            album = "", 
            description = "",
            label = "",
            disc = "",
            playlist = "",
            trackAuthor = ""
        } = req.body;

        // 4. Проверка наличия обязательных метаданных
        if (!title || !genre || !cover) {
            return res.status(400).json({ 
                message: "Поля 'Название', 'Жанр' и 'Обложка' обязательны." 
            });
        }

        // 5. Проверка наличия загруженного файла (музыкального трека)
        if (!req.file) {
            console.log("❌ Ошибка: Файл трека не получен. Возможно, ошибка multer (размер или тип).");
            return res.status(400).json({
                message: "Файл трека не был загружен. Убедитесь, что используется 'multipart/form-data' и поле 'track'."
            });
        }

        // 6. Создание нового документа трека в базе данных
        const track = await Track.create({
            title,
            genre,
            cover,
            
            // trackname — имя файла, присвоенное multer (например, 1678888888-12345.mp3)
            trackname: req.file.filename, 

            authorId: authorId, 
            authorName: authorName, 
            
            album,
            description,
            label,
            disc,
            playlist,
            trackAuthor
        });

        // 7. Успешный ответ
        res.json({
            success: true,
            message: "Трек успешно опубликован!",
            trackId: track._id,
            track
        });

    } catch (err) {
        console.error("⛔ Ошибка при загрузке трека (PostTrack):", err);
        
        // Обработка ошибок валидации Mongoose (теперь это не 500, а 400)
        if (err.name === 'ValidationError') {
             // Собираем все сообщения об ошибках валидации
             const messages = Object.values(err.errors).map(e => e.message).join(', ');
             return res.status(400).json({
                message: `Ошибка валидации данных трека: ${messages}`
            });
        }

        // Общая ошибка сервера
        res.status(500).json({
            message: "Не удалось опубликовать трек. Попробуйте снова.",
        });
    }
};
export const RecomendAuthor = async (req, res) => {
  try {
    const users = [
      {
        name: "Абдула Алишер Тагирович",
        age: 23,
        city: "Таганрог, Россия",
        favs: ["Кристина Орбакайте", "Шаман"]
      },
      {
        name: "Шептун Парамазий Огстрович",
        age: 34,
        city: "Самара, Россия",
        favs: ["Песняры", "The Rolling Stones"]
      },
      {
        name: "Раштуин Мухамад Арманович",
        age: 65,
        city: "Казань, Россия",
        favs: ["Бутырка", "Михаил Круг", "Алла Пугачева", "Владимир Ждамиров"]
      },
      {
        name: "Абдула Асылбек Краткович",
        age: 43,
        city: "Астана",
        favs: ["Чихизбаг"]
      },
      {
        name: "Василек Пятрусь Якубовский",
        age: 32,
        city: "Беларусь",
        favs: ["Песняры", "ВИА Ключик", "Янка Купала"]
      }
    ];

    const similar_artists = {
      "Кристина Орбакайте": ["Алла Пугачева", "Филипп Киркоров"],
      "Шаман": ["Дима Билан", "Земфира"],
      "Песняры": ["ВИА Ключик", "Ляпис Трубецкой"],
      "The Rolling Stones": ["The Beatles", "Queen"],
      "Бутырка": ["Михаил Круг", "Владимир Ждамиров"],
      "Михаил Круг": ["Бутырка", "Владимир Ждамиров"],
      "Алла Пугачева": ["Кристина Орбакайте", "Ирина Аллегрова"],
      "Владимир Ждамиров": ["Бутырка", "Михаил Круг"],
      "Чихизбаг": ["SHAMAN", "Дима Билан"],
      "ВИА Ключик": ["Песняры", "Янка Купала"],
      "Янка Купала": ["Песняры", "ВИА Ключик"]
    };

   


    // Функция рекомендаций
    function recommend(user) {
      const { name, favs } = user;
      let recs = [];

      for (const artist of favs) {
        if (similar_artists[artist]) {
          recs.push(...similar_artists[artist]);
        }
      }
      recs = [...new Set(recs)].filter(r => !favs.includes(r));

      return { name, recommendations: recs };
    }

    const result = users.map(u => recommend(u));

    return res.json({
      message: "Рекомендации готовы",
      recommendations: result
    });

  } catch (err) {
    console.log("🔥 Ошибка рекомендаций:", err);
    return res.status(500).json({ message: "Ошибка рекомендаций", error: err.message });
  }
};


// В stream.js

export const removeTrackFromPlaylist = async (req, res) => {
  try {
    const { playlistId, trackId } = req.params;
    const userId = req.userId; // Получаем из checkAuth

    // Находим плейлист и проверяем, что автор — текущий пользователь
    const playlist = await PlaylistModel.findOneAndUpdate(
      { _id: playlistId, author: userId },
      { $pull: { tracks: trackId } }, // Удаляем trackId из массива tracks
      { new: true }
    );

    if (!playlist) {
      return res.status(404).json({ message: "Плейлист не найден или доступ запрещен" });
    }

    res.json({ message: "Трек удален из плейлиста", playlist });
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Не удалось удалить трек" });
  }
};

// В файле music/stream.js

export const updatePlaylist = async (req, res) => {
  try {
    // Получаем данные из запроса, ВКЛЮЧАЯ tracks
    const { title, description, cover, tracks } = req.body;

    // Ищем плейлист, где автор — текущий пользователь
    const playlist = await PlaylistModel.findOne({ 
      _id: req.params.id, 
      author: req.userId 
    });

    if (!playlist) {
      return res.status(403).json({ message: "Плейлист не найден или нет доступа" });
    }

    // Обновляем поля, только если они пришли в запросе
    if (title) playlist.title = title;
    if (description !== undefined) playlist.description = description;
    if (cover) playlist.cover = cover;
    
    // ВАЖНО: Обновляем массив треков
    if (tracks) {
      playlist.tracks = tracks;
    }

    await playlist.save();

    // Возвращаем обновленный плейлист с развернутыми треками (populate)
    // Это важно, чтобы на фронте сразу отобразились картинки и названия
    const result = await PlaylistModel.findById(playlist._id).populate('tracks');

    res.json(result);
  } catch (err) {
    console.error("Ошибка updatePlaylist:", err);
    res.status(500).json({ message: "Не удалось обновить плейлист" });
  }
};

// music/stream.js
export const getFlow = async (req, res) => {
  try {
    const tracks = await TrackModel.aggregate([
      { $sample: { size: 20 } }, // Берем пачку случайных треков
      {
        $project: {
          title: 1,
          trackname: 1,
          cover: 1,
          authorName: 1,
          genre: 1,
        }
      }
    ]);
    res.json(tracks);
  } catch (err) {
    res.status(500).json({ message: "Ошибка потока" });
  }
};

// Получение всех публичных плейлистов (для главной страницы)
export const getAllPlaylists = async (req, res) => {
  try {
    // Показываем только публичные
    const playlists = await PlaylistModel.find({ isPublic: true })
      .populate('tracks')
      .limit(20);
    res.json(playlists);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Не удалось получить плейлисты" });
  }
};
export const getMyPlaylists = async (req, res) => {
  try {
    // Ищем плейлисты, где автор — текущий пользователь
    const playlists = await PlaylistModel.find({ author: req.userId })
      .populate('tracks')
      .sort({ createdAt: -1 });
    
    res.json(playlists);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Не удалось загрузить ваши плейлисты" });
  }
};
// Создание плейлиста
export const createPlaylist = async (req, res) => {
  try {
    const doc = new PlaylistModel({
      title: req.body.title,
      description: req.body.description || "",
      // Если с фронта пришло isPrivate, то isPublic = false
      isPublic: req.body.isPublic !== undefined ? req.body.isPublic : true, 
      author: req.userId,
      tracks: []
    });

    const playlist = await doc.save();
    res.json(playlist);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Ошибка при создании плейлиста" });
  }
};
// Получение одного плейлиста по ID
export const getOnePlaylist = async (req, res) => {
    try {
      const playlist = await PlaylistModel.findById(req.params.id).populate('tracks');
      if (!playlist) return res.status(404).json({ message: 'Плейлист не найден' });
      res.json(playlist);
    } catch (err) {
      res.status(500).json({ message: 'Ошибка сервера' });
    }
  };