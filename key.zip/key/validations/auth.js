import { body } from 'express-validator';
import { FORBIDDEN_USERNAMES } from '../utils/forbidden-usernames.js';



export const dhubRegisterValidation = [

  body('password', 'Пароль должен быть минимум 6 символов').isLength({ min: 6 }),

  body('fullName', 'Full name должен содержать минимум 3 символа').isLength({ min: 3 }),

  body('programmingLanguage', 'Укажите язык программирования').notEmpty(),

  body('gender').optional().isIn(['мужской', 'женский']),

  body('email').optional().isEmail().withMessage('Некорректный email'),

  body('country').optional().isString(),

  body('atomNick').optional().matches(/^@[A-Za-z0-9_]+$/).withMessage('Некорректный ник AtomGlide'),

  body('educationInstitution').optional().isString(),

  body('projectsPosition').optional().isString(),

  body('about').optional().isLength({ max: 500 }).withMessage('Описание не должно превышать 500 символов'),

];

export const dhubLoginValidation = [
  body('loginOrEmail', 'Укажите логин или email').notEmpty(),
  body('password', 'Пароль обязателен').notEmpty()
];

export const registerValidation = [
    body('username', 'Username должен начинаться с @ и содержать 3-20 символов')
        .isLength({ min: 3, max: 20 })
        .matches(/^@[a-zA-Z0-9_]+$/)
        .custom(async (value) => {
            const cleanUsername = value.toLowerCase().replace('@', '');
            if (FORBIDDEN_USERNAMES.includes(cleanUsername)) {
                throw new Error('Этот username запрещен к использованию');
            }
            return true;
        }),
    body('password', 'Пароль должен быть минимум 6 символов').isLength({ min: 6 }),
    body('fullName', 'Укажите имя (минимум 3 символа)').isLength({ min: 3 }),
    body('about', 'Описание не должно превышать 500 символов').optional().isLength({ max: 500 }),
    body('avatar').optional().isString(),
    body('cover').optional().isString()
];

export const loginValidation = [
    body('password', 'Пароль должен быть минимум 6 символов').isLength({ min: 6 })
];

export const musicValidation = [
    body('title').trim().notEmpty().withMessage('Название трека обязательно'),
    body('artist').trim().notEmpty().withMessage('Исполнитель обязателен'),
    body('genre').trim().notEmpty().withMessage('Укажите жанр'),
    body('lyrics').optional().trim(),
    body('explicit').optional().toBoolean(),
    body('isPodcast').optional().toBoolean()
  ];

export const changePasswordValidation = [
    body('currentPassword').notEmpty().withMessage('Текущий пароль обязателен'),
    body('newPassword')
      .isLength({ min: 6 }).withMessage('Пароль должен содержать минимум 6 символов')
      .not().equals(body('currentPassword')).withMessage('Новый пароль должен отличаться от старого')
];

export const PostCreateValidation = [
    body('title', 'Заголовок должен содержать минимум 1 символов')
        .isLength({ min: 1 })
        .isString(),
    body('imageUrl', 'Некорректный URL изображения').optional().isString(),
    body('user', 'Некорректный ID пользователя').optional().isMongoId()
];

export const updateUserValidator = [
    body('username', 'Нельзя изменить username').optional().isEmpty(),
    body('fullName', 'Имя должно содержать минимум 3 символа').optional().isLength({ min: 3 }),
    body('about', 'Описание не должно превышать 500 символов').optional().isLength({ max: 500 }),
    body('theme', 'Недопустимая тема').optional().isIn(['light', 'dark', 'blue', 'green', 'purple']),
    body('removeAvatar', 'Должно быть boolean').optional().isBoolean(),
    body('removeCover', 'Должно быть boolean').optional().isBoolean()
];