import { body } from 'express-validator';


export const channelCreateValidation = [
  body('username')
    .isString()
    .withMessage('Никнейм должен быть строкой')
    .matches(/^![a-zA-Z0-9_]{3,20}$/)
    .withMessage('Никнейм должен начинаться с ! и содержать 3-20 символов (буквы, цифры, _)'),
  
  body('title')
    .isString()
    .withMessage('Название должно быть строкой')
    .isLength({ min: 1, max: 100 })
    .withMessage('Название должно содержать от 1 до 100 символов'),
  
  body('description')
    .optional()
    .isString()
    .withMessage('Описание должно быть строкой')
    .isLength({ max: 500 })
    .withMessage('Описание не должно превышать 500 символов'),
  
  body('secure')
    .optional()
    .isBoolean()
    .withMessage('Параметр secure должен быть булевым значением')
];


export const channelUpdateValidation = [
  body('title')
    .optional()
    .isString()
    .withMessage('Название должно быть строкой')
    .isLength({ min: 1, max: 100 })
    .withMessage('Название должно содержать от 1 до 100 символов'),
  
  body('description')
    .optional()
    .isString()
    .withMessage('Описание должно быть строкой')
    .isLength({ max: 500 })
    .withMessage('Описание не должно превышать 500 символов'),
  
  body('secure')
    .optional()
    .isBoolean()
    .withMessage('Параметр secure должен быть булевым значением')
];


export const channelPostCreateValidation = [
  body('text')
    .isString()
    .withMessage('Текст должен быть строкой')
    .isLength({ min: 1, max: 5000 })
    .withMessage('Текст должен содержать от 1 до 5000 символов'),
  
  body('images')
    .optional()
    .isArray({ max: 3 })
    .withMessage('Максимум 3 изображения в посте'),
  
  body('images.*')
    .optional()
    .isString()
    .withMessage('Каждое изображение должно быть строкой (путь к файлу)'),
  
  body('secure')
    .optional()
    .isBoolean()
    .withMessage('Параметр secure должен быть булевым значением')
];


export const channelPostUpdateValidation = [
  body('text')
    .optional()
    .isString()
    .withMessage('Текст должен быть строкой')
    .isLength({ min: 1, max: 5000 })
    .withMessage('Текст должен содержать от 1 до 5000 символов'),
  
  body('images')
    .optional()
    .isArray({ max: 3 })
    .withMessage('Максимум 3 изображения в посте'),
  
  body('images.*')
    .optional()
    .isString()
    .withMessage('Каждое изображение должно быть строкой (путь к файлу)'),
  
  body('secure')
    .optional()
    .isBoolean()
    .withMessage('Параметр secure должен быть булевым значением')
]; 